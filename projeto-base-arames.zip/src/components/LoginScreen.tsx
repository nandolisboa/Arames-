import { Eye, EyeOff } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { ARAMES_LOGO_DATA_URL } from '../assets/logo';

const REMEMBER_USER_KEY = 'arames_remember_user';
const REMEMBER_EMAIL_KEY = 'arames_remembered_email';

interface LoginScreenProps {
  busy: boolean;
  error: string;
  onLogin: (email: string, password: string, rememberUser: boolean) => Promise<void>;
}

export function LoginScreen({ busy, error, onLogin }: LoginScreenProps) {
  const [rememberUser, setRememberUser] = useState<boolean>(() => {
    try {
      return localStorage.getItem(REMEMBER_USER_KEY) !== '0';
    } catch {
      return true;
    }
  });
  const [email, setEmail] = useState<string>(() => {
    try {
      if (localStorage.getItem(REMEMBER_USER_KEY) === '0') return '';
      return localStorage.getItem(REMEMBER_EMAIL_KEY) || '';
    } catch {
      return '';
    }
  });
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const passwordRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try {
      localStorage.setItem(REMEMBER_USER_KEY, rememberUser ? '1' : '0');
      if (!rememberUser) {
        localStorage.removeItem(REMEMBER_EMAIL_KEY);
      }
    } catch {
      // ignore storage errors
    }
  }, [rememberUser]);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    void onLogin(email, password, rememberUser);
  };

  return (
    <div className="login-shell" id="login">
      <div className="login-card-wrap">
        <div className="login-top-bar">
          <div className="brand">
            <img
              alt="Arames Brasil"
              className="brand-logo"
              src={ARAMES_LOGO_DATA_URL}
            />
          </div>
        </div>

        <section className="card login-card">
          <form className="login-form" onSubmit={handleSubmit}>
            <div className="field">
              <input
                aria-label="E-mail"
                autoComplete="username"
                id="email"
                name="email"
                placeholder="E-mail"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    passwordRef.current?.focus();
                  }
                }}
              />
            </div>

            <div className="field">
              <div className="login-input-wrap password-input-flex">
                <input
                  ref={passwordRef}
                  aria-label="Senha"
                  autoComplete="current-password"
                  id="password"
                  name="password"
                  placeholder="Senha"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <button
                  aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}
                  className="password-eye-btn"
                  id="togglePassword"
                  title={showPassword ? 'Ocultar senha' : 'Mostrar senha'}
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                >
                  {showPassword ? (
                    <EyeOff aria-hidden="true" size={17} />
                  ) : (
                    <Eye aria-hidden="true" size={17} />
                  )}
                </button>
              </div>
            </div>

            <label className="login-remember" htmlFor="rememberUser">
              <input
                checked={rememberUser}
                id="rememberUser"
                type="checkbox"
                onChange={(e) => setRememberUser(e.target.checked)}
              />
              <span>Lembrar usuário</span>
            </label>

            <button
              className="btn login-submit-btn"
              disabled={busy}
              id="loginBtn"
              type="submit"
            >
              {busy ? 'Entrando…' : 'Entrar'}
            </button>

            <div
              aria-live="polite"
              className={`login-error-box${error ? '' : ' hidden'}`}
              id="loginError"
              role="alert"
            >
              {error}
            </div>
          </form>
        </section>
      </div>
    </div>
  );
}
