import { useEffect, useRef, useState } from 'react';
import { OPERATORS, rowDate, today } from '../constants';
import type { AppProfile, GoalTargets, OperatorName, ProductionRow } from '../types';

interface GoalItemProps {
  operator: OperatorName;
  amount: number;
  target: number;
  isAdmin: boolean;
  open: boolean;
  onSaveGoal: (op: OperatorName, target: number) => Promise<void>;
}

function GoalItem({
  operator,
  amount,
  target,
  isAdmin,
  open,
  onSaveGoal,
}: GoalItemProps) {
  const [draftTarget, setDraftTarget] = useState(String(target));
  const [saving, setSaving] = useState(false);
  const fillRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setDraftTarget(String(target));
  }, [target]);

  const pct = target > 0 ? (amount / target) * 100 : 0;

  useEffect(() => {
    if (fillRef.current && open) {
      fillRef.current.style.width = `${Math.min(pct, 100)}%`;
    }
  }, [pct, open]);

  const handleSave = async () => {
    setSaving(true);
    try {
      await onSaveGoal(operator, Number(draftTarget));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="goal-item">
      <div className="goal-title">
        <span>{operator}</span>
        <span>{Math.floor(pct)}%</span>
      </div>
      <div
        aria-label={`Progresso mensal de ${operator}`}
        aria-valuemax={target}
        aria-valuemin={0}
        aria-valuenow={Math.min(amount, target)}
        className="goal-track"
        role="progressbar"
      >
        <div
          ref={fillRef}
          className={`goal-fill${amount >= target ? ' complete' : ''}`}
        />
      </div>
      <div className="goal-values">
        {amount.toLocaleString('pt-BR')} / {target.toLocaleString('pt-BR')} peças
      </div>
      {isAdmin && (
        <div className="goal-edit">
          <input
            aria-label={`Meta mensal de ${operator}`}
            max={100000000}
            min={1}
            step={1}
            type="number"
            value={draftTarget}
            onChange={(e) => setDraftTarget(e.target.value)}
          />
          <button
            className="btn secondary small"
            disabled={saving}
            type="button"
            onClick={() => void handleSave()}
          >
            Editar meta
          </button>
        </div>
      )}
    </div>
  );
}

interface GoalProgressProps {
  open: boolean;
  onClose: () => void;
  profile: AppProfile | null;
  allRows: ProductionRow[];
  goalTargets: GoalTargets;
  isAdmin: boolean;
  readAll: boolean;
  onSaveGoal: (op: OperatorName, target: number) => Promise<void>;
}

export function GoalProgress({
  open,
  onClose,
  profile,
  allRows,
  goalTargets,
  isAdmin,
  readAll,
  onSaveGoal,
}: GoalProgressProps) {
  const dialogRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const dlg = dialogRef.current;
    if (!dlg) return;
    if (open && !dlg.open) {
      dlg.showModal();
    } else if (!open && dlg.open) {
      dlg.close();
    }
  }, [open]);

  if (!profile) return null;

  const month = today().slice(0, 7);
  const candidateOps: OperatorName[] = readAll
    ? [...OPERATORS]
    : OPERATORS.includes(profile.display_name as OperatorName)
      ? [profile.display_name as OperatorName]
      : [];

  if (candidateOps.length === 0) return null;

  return (
    <dialog
      ref={dialogRef}
      aria-labelledby="goalsDialogTitle"
      className="confirm-dialog metas-dialog"
      id="goalsDialog"
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
      onClick={(e) => {
        if (e.target === dialogRef.current) {
          onClose();
        }
      }}
    >
      <div className="metas-dialog-head">
        <h2 id="goalsDialogTitle">METAS</h2>
        <button
          aria-label="Fechar janela de metas"
          className="btn secondary small"
          type="button"
          onClick={onClose}
        >
          Fechar
        </button>
      </div>
      <section className="goal-section" id="goalCard">
        <div className="goal-grid" id="goalProgress">
          {candidateOps.map((op) => {
            const target = Number(goalTargets[op] || 100000);
            const amount = allRows
              .filter(
                (r) =>
                  r.operator === op &&
                  rowDate(r.production_date).slice(0, 7) === month
              )
              .reduce((sum, r) => sum + Number(r.total_pieces || 0), 0);

            return (
              <GoalItem
                key={op}
                amount={amount}
                isAdmin={isAdmin}
                open={open}
                operator={op}
                target={target}
                onSaveGoal={onSaveGoal}
              />
            );
          })}
        </div>
      </section>
    </dialog>
  );
}
