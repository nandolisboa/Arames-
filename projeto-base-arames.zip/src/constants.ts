import type { GaugeType, GoalTargets, OperatorName, PackageKind } from './types';

export const SUPABASE_URL = 'https://ohtrlfyncanrqjukaggo.supabase.co';
export const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_Yaa1244QiYU1SemZlpTrgA_eLdUGuow';

export const PAGE_SIZE = 6;

export const OPERATORS: readonly OperatorName[] = ['Fernando', 'Angelo', 'Denerval'];
export const GAUGES: readonly GaugeType[] = ['3,8', '4,2', '5,0', '6,0'];
export const KINDS: readonly PackageKind[] = ['PACOTE', 'AMARRADO', 'M.LIVRE', 'CAIXA'];

export const DEFAULT_GOALS: GoalTargets = {
  Fernando: 100000,
  Angelo: 100000,
  Denerval: 100000,
};

export const MESSAGES = {
  profileMissing:
    'Esta conta não está associada a um perfil. Peça ao Admin Master para conferir app_profiles.',
  profileInvalid:
    'O perfil está incompleto ou não corresponde a um operador válido. Peça ao Admin Master para conferir app_profiles.',
  requiredFields: 'Confira os campos destacados e complete os dados.',
  reportTitle: 'Relatório de Produção de Estribos',
  coilsTitle: 'Relatório de Bobinas',
  reportNoRows: 'Nenhuma produção encontrada no período selecionado.',
  pdfLoad: 'Não foi possível carregar o gerador de PDF. Confira a conexão e tente novamente.',
  xlsxLoad: 'A biblioteca Excel não carregou. Confira a conexão e tente novamente.',
  pdfProductionOk: 'PDF da produção baixado.',
  pdfCoilsOk: 'PDF de bobinas baixado.',
  xlsxOk: 'Arquivo Excel baixado.',
} as const;

export const rowDate = (value: unknown): string => String(value ?? '').slice(0, 10);

export const today = (): string => {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
};

export const fmtDate = (s: string): string => {
  if (!s) return '';
  const [y, m, d] = s.split('-');
  return `${d}/${m}/${y}`;
};

export const validDate = (s: string): boolean => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T12:00:00`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
};

export const gaugeTextClass = (gauge: string): string => {
  const map: Record<string, string> = {
    '3,8': 'gauge-text-38',
    '4,2': 'gauge-text-42',
    '5,0': 'gauge-text-50',
    '6,0': 'gauge-text-60',
  };
  return map[String(gauge)] || '';
};

export const packageValueForLetter = (letter: string): PackageKind | '' => {
  const normalized = String(letter).trim().toUpperCase();
  if (!normalized) return '';
  const map: Record<string, PackageKind> = {
    P: 'PACOTE',
    A: 'AMARRADO',
    M: 'M.LIVRE',
    C: 'CAIXA',
  };
  return map[normalized.charAt(0)] || '';
};

export const gaugeValueForDigit = (digit: string): GaugeType | '' => {
  const map: Record<string, GaugeType> = {
    '3': '3,8',
    '4': '4,2',
    '5': '5,0',
    '6': '6,0',
  };
  return map[digit] || '';
};
