import { useEffect, useRef } from 'react';
import { OPERATORS } from '../constants';
import type { ProductionRow } from '../types';

interface ProductionSummaryDialogProps {
  open: boolean;
  monthLabel: string;
  rows: ProductionRow[];
  totalMonthPieces: number;
  onClose: () => void;
}

export function ProductionSummaryDialog({
  open,
  monthLabel,
  rows,
  totalMonthPieces,
  onClose,
}: ProductionSummaryDialogProps) {
  const summaryDialogRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const dialog = summaryDialogRef.current;
    if (!dialog) return;
    if (open && !dialog.open) dialog.showModal();
    else if (!open && dialog.open) dialog.close();
  }, [open]);

  return (
    <dialog
      ref={summaryDialogRef}
      aria-labelledby="production-summary-title"
      className="production-summary-dialog"
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
      onClose={() => {
        if (open) onClose();
      }}
      onClick={(e) => {
        if (e.target === summaryDialogRef.current) {
          onClose();
        }
      }}
    >
      <div className="production-summary-top">
        <div>
          <span className="production-summary-kicker">ARAMES BRASIL</span>
          <h2 id="production-summary-title">Resumo da produção</h2>
          <p>{monthLabel}</p>
        </div>
        <button
          aria-label="Fechar resumo"
          className="production-summary-close"
          type="button"
          onClick={onClose}
        >
          ×
        </button>
      </div>
      <div className="production-summary-highlight">
        <span>Total de {monthLabel}</span>
        <strong>{totalMonthPieces.toLocaleString('pt-BR')}</strong>
        <span>peças produzidas</span>
      </div>
      <div className="production-summary-list">
        {OPERATORS.map((op) => (
          <div key={op} className="production-summary-row">
            <span>{op}</span>
            <strong>
              {rows
                .filter((row) => row.operator === op)
                .reduce((sum, row) => sum + (Number(row.total_pieces) || 0), 0)
                .toLocaleString('pt-BR')}{' '}
              peças
            </strong>
          </div>
        ))}
      </div>
      <p className="production-summary-footnote">
        Considera somente o mês atual. Meses anteriores são agrupados no Histórico mensal a partir dos lançamentos existentes.
      </p>
      <button
        className="btn secondary production-summary-done"
        type="button"
        onClick={onClose}
      >
        Fechar
      </button>
    </dialog>
  );
}
