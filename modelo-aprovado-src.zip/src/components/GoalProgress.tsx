import { useEffect, useMemo, useRef, useState } from 'react';
import { OPERATORS, fmtMonthYear, rowDate, today } from '../constants';
import type { AppProfile, GoalTargets, OperatorName, ProductionRow } from '../types';

interface GoalItemProps {
  operator: OperatorName;
  amount: number;
  target: number;
  isAdmin: boolean;
  open: boolean;
  onSaveGoal: (op: OperatorName, target: number) => Promise<void>;
}

function GoalItem({
  operator,
  amount,
  target,
  isAdmin,
  open,
  onSaveGoal,
}: GoalItemProps) {
  const [draftTarget, setDraftTarget] = useState(String(target));
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setDraftTarget(String(target));
  }, [target]);

  const pct = target > 0 ? (amount / target) * 100 : 0;
  const fillWidth = open ? `${Math.min(pct, 100)}%` : '0%';

  const handleSave = async () => {
    setSaving(true);
    try {
      await onSaveGoal(operator, Number(draftTarget));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="goal-item">
      <div className="goal-title">
        <span>{operator}</span>
        <span>{Math.floor(pct)}%</span>
      </div>
      <div
        aria-label={`Progresso mensal de ${operator}`}
        aria-valuemax={target}
        aria-valuemin={0}
        aria-valuenow={Math.min(amount, target)}
        className="goal-track"
        role="progressbar"
      >
        <div
          className={`goal-fill${amount >= target ? ' complete' : ''}`}
          style={{ width: fillWidth }}
        />
      </div>
      <div className="goal-values">
        {amount.toLocaleString('pt-BR')} / {target.toLocaleString('pt-BR')} peças
      </div>
      {isAdmin && (
        <div className="goal-edit">
          <input
            aria-label={`Meta mensal de ${operator}`}
            max={100000000}
            min={1}
            step={1}
            type="number"
            value={draftTarget}
            onChange={(e) => setDraftTarget(e.target.value)}
          />
          <button
            className="btn secondary small"
            disabled={saving}
            type="button"
            onClick={() => void handleSave()}
          >
            {saving ? 'Salvando…' : 'Salvar meta'}
          </button>
        </div>
      )}
    </div>
  );
}

interface GoalProgressProps {
  open: boolean;
  onClose: () => void;
  profile: AppProfile | null;
  allRows: ProductionRow[];
  goalTargets: GoalTargets;
  currentMonth?: string;
  isAdmin: boolean;
  readAll: boolean;
  onSaveGoal: (op: OperatorName, target: number) => Promise<void>;
}

export function GoalProgress({
  open,
  onClose,
  profile,
  allRows,
  goalTargets,
  currentMonth,
  isAdmin,
  readAll,
  onSaveGoal,
}: GoalProgressProps) {
  const dialogRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const dlg = dialogRef.current;
    if (!dlg) return;
    if (open && !dlg.open) {
      dlg.showModal();
    } else if (!open && dlg.open) {
      dlg.close();
    }
  }, [open]);

  const month = currentMonth || today().slice(0, 7);

  const monthlyTotals = useMemo(() => {
    const totals: Record<string, number> = {};
    for (const r of allRows) {
      if (rowDate(r.production_date).slice(0, 7) === month) {
        totals[r.operator] = (totals[r.operator] || 0) + Number(r.total_pieces || 0);
      }
    }
    return totals;
  }, [allRows, month]);

  if (!profile) return null;

  const candidateOps: OperatorName[] = readAll
    ? [...OPERATORS]
    : OPERATORS.includes(profile.display_name as OperatorName)
      ? [profile.display_name as OperatorName]
      : [];

  if (candidateOps.length === 0) return null;

  return (
    <dialog
      ref={dialogRef}
      aria-labelledby="goalsDialogTitle"
      className="confirm-dialog metas-dialog"
      id="goalsDialog"
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
      onClose={() => {
        if (open) onClose();
      }}
      onClick={(e) => {
        if (e.target === dialogRef.current) {
          onClose();
        }
      }}
    >
      <div className="metas-dialog-head">
        <h2 id="goalsDialogTitle">METAS — {fmtMonthYear(month)}</h2>
        <button
          aria-label="Fechar janela de metas"
          className="btn secondary small"
          type="button"
          onClick={onClose}
        >
          Fechar
        </button>
      </div>
      <section className="goal-section" id="goalCard">
        <div className="goal-grid" id="goalProgress">
          {candidateOps.map((op) => {
            const target = Number(goalTargets[op] || 100000);
            const amount = monthlyTotals[op] || 0;

            return (
              <GoalItem
                key={op}
                amount={amount}
                isAdmin={isAdmin}
                open={open}
                operator={op}
                target={target}
                onSaveGoal={onSaveGoal}
              />
            );
          })}
        </div>
      </section>
    </dialog>
  );
}
