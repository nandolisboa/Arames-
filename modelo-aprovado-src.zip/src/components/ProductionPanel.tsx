import { Search } from 'lucide-react';
import { useMemo, useState } from 'react';
import {
  OPERATORS,
  PAGE_SIZE,
  fmtDate,
  fmtMonthYear,
  gaugeTextClass,
  rowDate,
  today,
} from '../constants';
import {
  createProductionPdfPreview,
  exportProductionExcel,
  type PdfPreviewData,
  type PrintOperatorFilter,
} from '../lib/reports';
import type {
  AppProfile,
  DateFilter,
  OperatorName,
  ProductionRow,
} from '../types';
import { ConfirmDialog } from './ConfirmDialog';
import { PdfPreviewDialog } from './PdfPreviewDialog';
import {
  ProductionForm,
  type EditProductionRequest,
} from './ProductionForm';
import { ProductionSummaryDialog } from './ProductionSummaryDialog';

interface ProductionPanelProps {
  visible: boolean;
  profile: AppProfile | null;
  isAdmin: boolean;
  readAll: boolean;
  currentMonth: string;
  loadingRows: boolean;
  loadError: string;
  onRetryLoad: () => void;
  allRows: ProductionRow[];
  onlineOperators: Set<string>;
  onSaveProduction: (params: {
    editingId: string | number | null;
    production_date: string;
    operator: OperatorName;
    gauge: string;
    measure: string;
    package_type: string;
    pieces_per_unit: number;
    units: number;
  }) => Promise<{ ok: boolean; savedId?: string | number }>;
  onDeleteProduction: (id: string | number) => Promise<void>;
  onNotify: (msg: string) => void;
}

const DATE_FILTER_OPTIONS: { value: DateFilter; label: string }[] = [
  { value: 'month', label: 'Este mês' },
  { value: 'today', label: 'Hoje' },
];

export function ProductionPanel({
  visible,
  profile,
  isAdmin,
  readAll,
  currentMonth,
  loadingRows,
  loadError,
  onRetryLoad,
  allRows,
  onlineOperators,
  onSaveProduction,
  onDeleteProduction,
  onNotify,
}: ProductionPanelProps) {
  const [mobileView, setMobileView] = useState<'form' | 'list'>('form');
  const [editRequest, setEditRequest] = useState<EditProductionRequest | null>(
    null
  );

  const [dateFilter, setDateFilter] = useState<DateFilter>('month');
  const [productionSearch, setProductionSearch] = useState('');
  const [pages, setPages] = useState<Record<string, number>>({});
  const [expandedOperators, setExpandedOperators] = useState<
    Record<string, boolean>
  >({});
  const [searchExpandedOperators, setSearchExpandedOperators] = useState<
    Record<string, boolean>
  >({});

  const [printOperator, setPrintOperator] = useState<PrintOperatorFilter>('all');
  const [pdfPreview, setPdfPreview] = useState<PdfPreviewData | null>(null);
  const [summaryOpen, setSummaryOpen] = useState(false);
  const [pendingDeleteRow, setPendingDeleteRow] =
    useState<ProductionRow | null>(null);

  const currentMonthLabel = useMemo(
    () => fmtMonthYear(currentMonth),
    [currentMonth]
  );

  const currentMonthRows = useMemo(
    () =>
      allRows.filter(
        (r) => rowDate(r.production_date).slice(0, 7) === currentMonth
      ),
    [allRows, currentMonth]
  );

  const totalMonthPieces = useMemo(
    () =>
      currentMonthRows.reduce(
        (sum, row) => sum + (Number(row.total_pieces) || 0),
        0
      ),
    [currentMonthRows]
  );

  const todayStr = today();

  const periodRows = useMemo(() => {
    if (dateFilter === 'today') {
      return currentMonthRows.filter(
        (r) => rowDate(r.production_date) === todayStr
      );
    }
    return currentMonthRows;
  }, [currentMonthRows, dateFilter, todayStr]);

  const filteredRows = useMemo(() => {
    const tokens = productionSearch
      .trim()
      .toLocaleLowerCase('pt-BR')
      .split(/\s+/)
      .filter(Boolean);
    if (!tokens.length) return periodRows;

    return periodRows.filter((r) => {
      const rawDate = rowDate(r.production_date);
      const formattedDate = fmtDate(rawDate);
      const piecesRaw = String(r.pieces_per_unit);
      const piecesFmt = Number(r.pieces_per_unit).toLocaleString('pt-BR');
      const unitsRaw = String(r.units);
      const unitsFmt = Number(r.units).toLocaleString('pt-BR');
      const totalRaw = String(r.total_pieces);
      const totalFmt = Number(r.total_pieces).toLocaleString('pt-BR');

      const haystack = [
        r.operator,
        formattedDate,
        rawDate,
        r.measure,
        r.gauge,
        `${r.gauge} mm`,
        r.package_type,
        piecesRaw,
        piecesFmt,
        unitsRaw,
        unitsFmt,
        totalRaw,
        totalFmt,
      ]
        .join(' ')
        .toLocaleLowerCase('pt-BR');

      return tokens.every((token) => haystack.includes(token));
    });
  }, [periodRows, productionSearch]);

  const activeFilterNote = useMemo(() => {
    const parts: string[] = [`Mês: ${currentMonthLabel}`];
    if (dateFilter === 'today') parts.push('Período: Hoje');
    const trimmedSearch = productionSearch.trim();
    if (trimmedSearch) parts.push(`Busca: "${trimmedSearch}"`);
    return parts.join(' • ');
  }, [currentMonthLabel, dateFilter, productionSearch]);

  const productionPdfOptions = useMemo(
    () => ({
      titleBase: `Relatório de Produção de Estribos — ${currentMonthLabel}`,
      filenamePrefix: `relatorio_producao_${currentMonth}`,
    }),
    [currentMonth, currentMonthLabel]
  );

  const beginEdit = (r: ProductionRow) => {
    if (!isAdmin) return;
    setEditRequest((prev) => ({ row: r, seq: (prev?.seq ?? 0) + 1 }));
    setMobileView('form');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!visible) return null;

  const isAdministration = profile?.role === 'administration';
  const opsToRender = readAll
    ? OPERATORS
    : profile?.display_name
      ? [profile.display_name]
      : [];

  const hasActiveFilter =
    dateFilter !== 'month' || productionSearch.trim().length > 0;

  return (
    <section
      className={`production-workspace${isAdministration ? ' is-readonly' : ''}`}
      id="productionPanel"
    >
      {!isAdministration && (
        <div
          aria-label="Alternar entre registro e lista de produções"
          className="mobile-view-switch"
          role="tablist"
        >
          <button
            aria-selected={mobileView === 'form'}
            className={`mobile-view-btn${mobileView === 'form' ? ' active' : ''}`}
            role="tab"
            type="button"
            onClick={() => setMobileView('form')}
          >
            {editRequest ? 'Alterar' : 'Registrar'}
          </button>
          <button
            aria-selected={mobileView === 'list'}
            className={`mobile-view-btn${mobileView === 'list' ? ' active' : ''}`}
            role="tab"
            type="button"
            onClick={() => setMobileView('list')}
          >
            Produções ({filteredRows.length})
          </button>
        </div>
      )}

      {!isAdministration && (
        <ProductionForm
          currentMonth={currentMonth}
          editRequest={editRequest}
          isAdmin={isAdmin}
          mobileHidden={mobileView !== 'form'}
          profile={profile}
          onCancelEdit={() => {
            setEditRequest(null);
            setMobileView('list');
          }}
          onNotify={onNotify}
          onSaveProduction={onSaveProduction}
          onSavedSuccess={({
            wasEdit,
            operator: op,
            productionDate,
            gauge,
            measure,
            packageType,
            piecesPerUnit,
            units,
            savedId,
          }) => {
            setEditRequest(null);
            if (wasEdit) {
              setMobileView('list');
              return;
            }
            if (productionSearch) {
              setProductionSearch('');
              setSearchExpandedOperators({});
            }
            const savedMonth = productionDate.slice(0, 7);
            if (savedMonth < currentMonth) {
              onNotify(
                `Produção registrada em ${fmtMonthYear(savedMonth)}; ela aparece no Histórico mensal calculado a partir dos lançamentos.`
              );
              return;
            }
            if (dateFilter === 'today' && productionDate !== today()) {
              setDateFilter('month');
            }
            if (savedId !== undefined) {
              const nowIso = new Date().toISOString();
              const nextRowsForOperator = [
                {
                  id: savedId,
                  production_date: productionDate,
                  operator: op,
                  gauge,
                  measure,
                  package_type: packageType,
                  pieces_per_unit: piecesPerUnit,
                  units,
                  total_pieces: piecesPerUnit * units,
                  created_at: nowIso,
                },
                ...currentMonthRows.filter(
                  (r) => String(r.id) !== String(savedId)
                ),
              ]
                .filter((r) => r.operator === op)
                .sort((a, b) => {
                  const dateCmp = rowDate(b.production_date).localeCompare(
                    rowDate(a.production_date)
                  );
                  if (dateCmp !== 0) return dateCmp;
                  return String(b.created_at || '').localeCompare(
                    String(a.created_at || '')
                  );
                });
              const idx = nextRowsForOperator.findIndex(
                (r) => String(r.id) === String(savedId)
              );
              if (idx >= 0) {
                setPages((prev) => ({
                  ...prev,
                  [op]: Math.floor(idx / PAGE_SIZE),
                }));
              }
            }
          }}
        />
      )}

      <section
        className={`card production-records-card${
          !isAdministration && mobileView !== 'list' ? ' mobile-pane-hidden' : ''
        }`}
      >
        <div className="sectionhead">
          <h2 id="panelTitle">
            {readAll
              ? `Produção dos 3 operadores — ${currentMonthLabel}`
              : `Minha produção — ${currentMonthLabel}`}
          </h2>
          {readAll && (
            <div className="tools">
              <select
                aria-label="Escolher operador para impressão"
                className="print-operator-select"
                id="printOperatorSelect"
                value={printOperator}
                onChange={(e) =>
                  setPrintOperator(e.target.value as PrintOperatorFilter)
                }
              >
                <option value="all">Todos os operadores</option>
                {OPERATORS.map((op) => (
                  <option key={op} value={op}>
                    {op}
                  </option>
                ))}
              </select>
              <button
                className="btn secondary small"
                id="printBtn"
                type="button"
                onClick={() => {
                  const preview = createProductionPdfPreview(
                    filteredRows,
                    onNotify,
                    printOperator,
                    activeFilterNote,
                    productionPdfOptions
                  );
                  if (preview) setPdfPreview(preview);
                }}
              >
                Imprimir
              </button>
              <button
                className="btn secondary small"
                id="exportExcelBtn"
                type="button"
                disabled={loadingRows || !!loadError || !filteredRows.length}
                onClick={() => exportProductionExcel(filteredRows, dateFilter, onNotify)}
              >
                Excel
              </button>
            </div>
          )}
        </div>

        {readAll && (
          <>
            <div className="production-grand-total" aria-live="polite">
              <div>
                <span className="production-grand-total-label">
                  Total de {currentMonthLabel}
                </span>
                <strong>
                  {loadingRows
                    ? 'Carregando…'
                    : loadError
                      ? 'Indisponível'
                      : `${totalMonthPieces.toLocaleString('pt-BR')} peças`}
                </strong>
              </div>
              {isAdministration && (
                <button
                  className="btn secondary small"
                  disabled={loadingRows || !!loadError}
                  type="button"
                  onClick={() => setSummaryOpen(true)}
                >
                  Ver resumo
                </button>
              )}
            </div>
            <ProductionSummaryDialog
              monthLabel={currentMonthLabel}
              open={summaryOpen}
              rows={currentMonthRows}
              totalMonthPieces={totalMonthPieces}
              onClose={() => setSummaryOpen(false)}
            />
          </>
        )}

        <div className="production-filters-bar">
          <div className="field coil-search-field search-input-wrap">
            <Search aria-hidden="true" className="search-icon" size={16} />
            <input
              aria-label="Pesquisar por nome, data, estribo / medida, tipo, pç/unid., unidades ou total pç"
              id="productionSearch"
              maxLength={120}
              placeholder="Buscar: nome, data, estribo, tipo, qtd. ou total"
              type="search"
              value={productionSearch}
              onChange={(e) => {
                setProductionSearch(e.target.value);
                setPages({});
                setSearchExpandedOperators({});
              }}
            />
          </div>

          <div
            aria-label="Filtrar produções por período"
            className="period-filter-group"
            role="group"
          >
            {DATE_FILTER_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                aria-pressed={dateFilter === opt.value}
                className={`period-filter-btn${dateFilter === opt.value ? ' active' : ''}`}
                type="button"
                onClick={() => {
                  setDateFilter(opt.value);
                  setPages({});
                  setSearchExpandedOperators({});
                }}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        <div className="groups" id="records">
          {loadingRows ? (
            <div className="empty">Carregando produções…</div>
          ) : loadError ? (
            <div className="empty load-error" role="alert">
              <p>{loadError}</p>
              <button
                className="btn secondary small"
                type="button"
                onClick={onRetryLoad}
              >
                Tentar novamente
              </button>
            </div>
          ) : !currentMonthRows.length ? (
            <div className="empty">
              Nenhuma produção registrada em {currentMonthLabel}.
              {allRows.length > 0 && (
                <span className="history-empty-note">
                  {' '}
                  Os meses anteriores estão agrupados na aba Histórico.
                </span>
              )}
            </div>
          ) : !filteredRows.length ? (
            <div className="empty">
              Nenhuma produção encontrada para os filtros selecionados.
            </div>
          ) : (
            opsToRender.map((op) => {
              const list = filteredRows.filter((r) => r.operator === op);
              if (!list.length) return null;
              const pageCount = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
              const currentPage = Math.min(pages[op] || 0, pageCount - 1);
              const shown = list.slice(
                currentPage * PAGE_SIZE,
                (currentPage + 1) * PAGE_SIZE
              );
              const sum = list.reduce(
                (acc, r) => acc + Number(r.total_pieces),
                0
              );
              const isOnline = onlineOperators.has(op);
              const isExpanded = hasActiveFilter
                ? searchExpandedOperators[op] !== false
                : !!expandedOperators[op];

              return (
                <section key={op} className="operator">
                  <button
                    aria-expanded={isExpanded}
                    className="operator-title operator-toggle"
                    type="button"
                    onClick={() => {
                      if (hasActiveFilter) {
                        setSearchExpandedOperators((prev) => ({
                          ...prev,
                          [op]: prev[op] === false,
                        }));
                      } else {
                        setExpandedOperators((prev) => ({
                          ...prev,
                          [op]: !prev[op],
                        }));
                      }
                    }}
                  >
                    <span className="presence-name">
                      <span
                        aria-label={isOnline ? 'Online' : 'Offline'}
                        className={`presence-dot${isOnline ? ' is-online' : ''}`}
                        role="img"
                        title={isOnline ? 'Online' : 'Offline'}
                      />
                      <span className="operator-btn-label">{op}</span>
                      <span aria-hidden="true" className="operator-chevron">
                        {isExpanded ? '▾' : '▸'}
                      </span>
                    </span>
                    <span className="count">
                      {sum.toLocaleString('pt-BR')} peças
                    </span>
                  </button>
                  {isExpanded && (
                    <>
                      <div className="saved-table-wrap">
                        <table className="saved-table">
                          <thead>
                            <tr>
                              <th>DATA</th>
                              <th>ESTRIBO / MEDIDA</th>
                              <th>TIPO</th>
                              <th className="num">PÇ/UNID.</th>
                              <th className="num">UNIDADES</th>
                              <th className="num">TOTAL PÇ</th>
                              {isAdmin && <th />}
                            </tr>
                          </thead>
                          <tbody>
                            {shown.map((r) => (
                              <tr key={r.id}>
                                <td>{fmtDate(rowDate(r.production_date))}</td>
                                <td>
                                  <span className="saved-dimension">
                                    {r.measure || '—'}
                                  </span>
                                  <span
                                    className={`saved-measure ${gaugeTextClass(r.gauge)}`}
                                  >
                                    {r.gauge} mm
                                  </span>
                                </td>
                                <td>{r.package_type}</td>
                                <td className="num">
                                  {Number(r.pieces_per_unit).toLocaleString(
                                    'pt-BR'
                                  )}
                                </td>
                                <td className="num">
                                  {Number(r.units).toLocaleString('pt-BR')}
                                </td>
                                <td className="num total-cell">
                                  {Number(r.total_pieces).toLocaleString(
                                    'pt-BR'
                                  )}
                                </td>
                                {isAdmin && (
                                  <td className="saved-actions">
                                    <button
                                      className="btn secondary small"
                                      type="button"
                                      onClick={() => beginEdit(r)}
                                    >
                                      Alterar
                                    </button>
                                    <button
                                      className="btn danger small"
                                      type="button"
                                      onClick={() => setPendingDeleteRow(r)}
                                    >
                                      Apagar
                                    </button>
                                  </td>
                                )}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <div className="mobile-record-list">
                        {shown.map((r) => (
                          <article key={r.id} className="mobile-record-card">
                            <div className="mobile-record-top">
                              <div className="mobile-record-main">
                                <strong className="mobile-record-measure">
                                  {r.measure || '—'}
                                </strong>
                                <span aria-hidden="true" className="meta-sep">
                                  ·
                                </span>
                                <span
                                  className={`mobile-record-gauge ${gaugeTextClass(r.gauge)}`}
                                >
                                  {r.gauge} mm
                                </span>
                              </div>
                              <div className="mobile-record-total">
                                {Number(r.total_pieces).toLocaleString('pt-BR')}{' '}
                                pç
                              </div>
                            </div>
                            <div className="mobile-record-bottom">
                              <div className="mobile-record-meta">
                                <span>
                                  {fmtDate(rowDate(r.production_date))}
                                </span>
                                <span aria-hidden="true" className="meta-sep">
                                  ·
                                </span>
                                <span>{r.package_type}</span>
                                <span aria-hidden="true" className="meta-sep">
                                  ·
                                </span>
                                <span>
                                  {Number(r.pieces_per_unit).toLocaleString(
                                    'pt-BR'
                                  )}{' '}
                                  × {Number(r.units).toLocaleString('pt-BR')}
                                </span>
                              </div>
                              {isAdmin && (
                                <div className="mobile-record-actions">
                                  <button
                                    className="btn secondary small"
                                    type="button"
                                    onClick={() => beginEdit(r)}
                                  >
                                    Alterar
                                  </button>
                                  <button
                                    className="btn danger small"
                                    type="button"
                                    onClick={() => setPendingDeleteRow(r)}
                                  >
                                    Apagar
                                  </button>
                                </div>
                              )}
                            </div>
                          </article>
                        ))}
                      </div>
                      {pageCount > 1 && (
                        <div className="pager">
                          <button
                            className="btn secondary small"
                            disabled={currentPage === 0}
                            type="button"
                            onClick={() =>
                              setPages((prev) => ({
                                ...prev,
                                [op]: Math.max(0, currentPage - 1),
                              }))
                            }
                          >
                            Anterior
                          </button>
                          <span>
                            {currentPage * PAGE_SIZE + 1}–
                            {Math.min((currentPage + 1) * PAGE_SIZE, list.length)}{' '}
                            de {list.length}
                          </span>
                          <button
                            className="btn secondary small"
                            disabled={currentPage >= pageCount - 1}
                            type="button"
                            onClick={() =>
                              setPages((prev) => ({
                                ...prev,
                                [op]: Math.min(pageCount - 1, currentPage + 1),
                              }))
                            }
                          >
                            Próxima
                          </button>
                        </div>
                      )}
                    </>
                  )}
                </section>
              );
            })
          )}
        </div>
      </section>

      <PdfPreviewDialog
        preview={pdfPreview}
        selectedOperator={readAll ? printOperator : undefined}
        onChangeOperator={
          readAll
            ? (nextOp) => {
                setPrintOperator(nextOp);
                const preview = createProductionPdfPreview(
                  filteredRows,
                  onNotify,
                  nextOp,
                  activeFilterNote,
                  productionPdfOptions
                );
                if (preview) setPdfPreview(preview);
              }
            : undefined
        }
        onClose={() => setPdfPreview(null)}
        onNotify={onNotify}
      />

      <ConfirmDialog
        message="Apagar este registro?"
        open={!!pendingDeleteRow}
        onCancel={() => setPendingDeleteRow(null)}
        onConfirm={() => {
          const target = pendingDeleteRow;
          setPendingDeleteRow(null);
          if (target) {
            void onDeleteProduction(target.id);
          }
        }}
      />
    </section>
  );
}
