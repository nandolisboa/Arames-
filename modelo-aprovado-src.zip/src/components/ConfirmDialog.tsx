import { useEffect, useRef } from 'react';

interface ConfirmDialogProps {
  open: boolean;
  title?: string;
  message: string;
  acceptLabel?: string;
  cancelLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export function ConfirmDialog({
  open,
  title = 'Confirmar ação',
  message,
  acceptLabel = 'Apagar',
  cancelLabel = 'Cancelar',
  onConfirm,
  onCancel,
}: ConfirmDialogProps) {
  const dialogRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const dlg = dialogRef.current;
    if (!dlg) return;
    if (open && !dlg.open) {
      dlg.showModal();
    } else if (!open && dlg.open) {
      dlg.close();
    }
  }, [open]);

  return (
    <dialog
      ref={dialogRef}
      aria-describedby="confirmMessage"
      aria-labelledby="confirmTitle"
      className="confirm-dialog"
      id="confirmDialog"
      onCancel={(e) => {
        e.preventDefault();
        onCancel();
      }}
      onClose={() => {
        if (open) onCancel();
      }}
    >
      <h2 id="confirmTitle">{title}</h2>
      <p id="confirmMessage">{message}</p>
      <div className="confirm-actions">
        <button
          className="btn secondary"
          id="confirmCancel"
          type="button"
          onClick={onCancel}
        >
          {cancelLabel}
        </button>
        <button
          className="btn danger"
          id="confirmAccept"
          type="button"
          onClick={onConfirm}
        >
          {acceptLabel}
        </button>
      </div>
    </dialog>
  );
}
