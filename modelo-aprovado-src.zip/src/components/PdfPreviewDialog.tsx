import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { ARAMES_LOGO_DATA_URL } from '../assets/logo';
import {
  MESSAGES,
  OPERATORS,
  fmtDate,
  fmtKg,
  fmtMonthYear,
  fmtTimeFromIso,
  localDateFromIso,
  rowDate,
} from '../constants';
import { formatCoilWeightsForReport } from '../lib/coilWeights';
import {
  COILS_MONTHLY_DAY_COLUMNS,
  COILS_REPORT_COLUMNS,
  PRODUCTION_REPORT_COLUMNS,
  formatWeightSourceLabel,
  getCoilsMonthlyReportSummary,
  getProductionReportSummary,
  type PdfPreviewData,
  type PrintOperatorFilter,
} from '../lib/reports';

interface ReportDocumentProps {
  preview: PdfPreviewData;
}

function ReportDocument({ preview }: ReportDocumentProps) {
  const metaText = preview.filterNote
    ? `Emitido em ${preview.issuedAt} • ${preview.filterNote}`
    : `Emitido em ${preview.issuedAt}`;

  if (preview.type === 'production') {
    const rows = preview.productionRows || [];
    const operatorFilter = preview.operatorFilter ?? 'all';
    const { groups, grandTotal, totalLabel } = getProductionReportSummary(
      rows,
      operatorFilter
    );

    return (
      <div className="report-sheet report-sheet--production">
        <div className="report-sheet-header">
          <div>
            <h1 className="ptitle">{preview.title}</h1>
            <div className="pmeta">{metaText}</div>
          </div>
          <img
            alt="Arames Brasil"
            className="report-sheet-logo"
            src={ARAMES_LOGO_DATA_URL}
          />
        </div>

        {!rows.length ? (
          <div className="report-empty">{MESSAGES.reportNoRows}</div>
        ) : (
          <>
            {groups.map((group) => (
              <div key={group.operator} className="pgroup">
                <h2>{group.operator}</h2>
                <table>
                  <colgroup>
                    {PRODUCTION_REPORT_COLUMNS.map((col) => (
                      <col
                        key={col.label}
                        style={{ width: `${col.htmlWidthPct}%` }}
                      />
                    ))}
                  </colgroup>
                  <thead>
                    <tr>
                      {PRODUCTION_REPORT_COLUMNS.map((col) => (
                        <th
                          key={col.label}
                          className={col.align === 'right' ? 'num' : undefined}
                        >
                          {col.label}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {group.rows.map((r) => (
                      <tr key={r.id}>
                        <td>{fmtDate(rowDate(r.production_date))}</td>
                        <td>{r.gauge} mm</td>
                        <td>{r.measure || ''}</td>
                        <td>{r.package_type}</td>
                        <td className="num">
                          {Number(r.pieces_per_unit).toLocaleString('pt-BR')}
                        </td>
                        <td className="num">
                          {Number(r.units).toLocaleString('pt-BR')}
                        </td>
                        <td className="num">
                          {Number(r.total_pieces).toLocaleString('pt-BR')}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {groups.length > 1 && (
                  <div className="psum">
                    Subtotal {group.operator}:{' '}
                    {group.subtotal.toLocaleString('pt-BR')} peças
                  </div>
                )}
              </div>
            ))}
            <div className="report-grand-total">
              {totalLabel}: {grandTotal.toLocaleString('pt-BR')} peças
            </div>
          </>
        )}
      </div>
    );
  }

  if (preview.type === 'coils-monthly') {
    const coilRows = preview.coilRows || [];
    const month = preview.monthFilter || '';
    const summary = getCoilsMonthlyReportSummary(coilRows, month);

    return (
      <div className="report-sheet">
        <div className="report-sheet-header">
          <div>
            <h1 className="ptitle">{preview.title}</h1>
            <div className="pmeta">{metaText}</div>
          </div>
          <img
            alt="Arames Brasil"
            className="report-sheet-logo"
            src={ARAMES_LOGO_DATA_URL}
          />
        </div>

        {!summary.totalCount ? (
          <div className="report-empty">Nenhuma bobina cadastrada neste mês.</div>
        ) : (
          <>
            <div className="report-monthly-summary">
              <div>
                <span>Total de bobinas salvas no mês</span>
                <strong>{summary.totalCount}</strong>
              </div>
              <div>
                <span>Peso total cadastrado</span>
                <strong>{fmtKg(summary.totalWeightKg)}</strong>
              </div>
            </div>

            <div className="pgroup">
              <h2>Resumo por bitola</h2>
              <table>
                <thead>
                  <tr>
                    <th>Bitola</th>
                    <th className="num">Qtd. bobinas</th>
                    <th className="num">Peso total (kg)</th>
                  </tr>
                </thead>
                <tbody>
                  {summary.byGauge.map((g) => (
                    <tr key={g.gauge}>
                      <td>{g.gauge} mm</td>
                      <td className="num">{g.count}</td>
                      <td className="num">{fmtKg(g.totalWeightKg)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {summary.byDay.map((day) => (
              <div key={day.date} className="pgroup">
                <h2 className="report-day-heading">
                  <span>
                    {day.date === 'Sem data' ? 'Sem data' : fmtDate(day.date)}
                  </span>
                  <span>
                    {day.count} {day.count === 1 ? 'bobina' : 'bobinas'} •{' '}
                    {fmtKg(day.totalWeightKg)}
                  </span>
                </h2>
                <table>
                  <thead>
                    <tr>
                      {COILS_MONTHLY_DAY_COLUMNS.map((col) => (
                        <th
                          key={col.label}
                          className={col.align === 'right' ? 'num' : undefined}
                        >
                          {col.label}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {day.rows.map((c) => (
                      <tr key={c.id}>
                        <td>{fmtTimeFromIso(c.created_at) || '—'}</td>
                        <td>{c.gauge} mm</td>
                        <td>{c.manufacturer || ''}</td>
                        <td>{c.invoice_number || ''}</td>
                        <td>{c.invoice_series || ''}</td>
                        <td className="num">{formatCoilWeightsForReport(c)}</td>
                        <td>{formatWeightSourceLabel(c.weight_source)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ))}
          </>
        )}
      </div>
    );
  }

  const coilRows = preview.coilRows || [];

  return (
    <div className="report-sheet">
      <div className="report-sheet-header">
        <div>
          <h1 className="ptitle">{preview.title}</h1>
          <div className="pmeta">{metaText}</div>
        </div>
        <img
          alt="Arames Brasil"
          className="report-sheet-logo"
          src={ARAMES_LOGO_DATA_URL}
        />
      </div>

      <div className="pgroup">
        <table>
          <thead>
            <tr>
              {COILS_REPORT_COLUMNS.map((col) => (
                <th
                  key={col.label}
                  className={col.align === 'right' ? 'num' : undefined}
                >
                  {col.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {coilRows.length ? (
              coilRows.map((c) => (
                <tr key={c.id}>
                  <td>{fmtDate(localDateFromIso(c.created_at)) || '—'}</td>
                  <td>{c.gauge} mm</td>
                  <td>{c.manufacturer || ''}</td>
                  <td>{c.invoice_number || ''}</td>
                  <td>{c.invoice_series || ''}</td>
                  <td className="num">{formatCoilWeightsForReport(c)}</td>
                  <td>{formatWeightSourceLabel(c.weight_source)}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={COILS_REPORT_COLUMNS.length}>
                  Nenhuma bobina cadastrada
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

interface PdfPreviewDialogProps {
  preview: PdfPreviewData | null;
  selectedOperator?: PrintOperatorFilter;
  onChangeOperator?: (operator: PrintOperatorFilter) => void;
  selectedMonth?: string;
  onChangeMonth?: (month: string) => void;
  onClose: () => void;
  onNotify: (msg: string) => void;
}

export function PdfPreviewDialog({
  preview,
  selectedOperator,
  onChangeOperator,
  selectedMonth,
  onChangeMonth,
  onClose,
  onNotify,
}: PdfPreviewDialogProps) {
  const dialogRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const dlg = dialogRef.current;
    if (!dlg) return;
    if (preview && !dlg.open) {
      dlg.showModal();
    } else if (!preview && dlg.open) {
      dlg.close();
    }
  }, [preview]);

  const printAreaEl =
    typeof document !== 'undefined'
      ? document.getElementById('printArea')
      : null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <>
      <dialog
        ref={dialogRef}
        aria-labelledby="pdfPreviewTitle"
        className="confirm-dialog pdf-preview-dialog"
        id="pdfPreviewDialog"
        onCancel={(e) => {
          e.preventDefault();
          onClose();
        }}
        onClose={() => {
          if (preview) onClose();
        }}
        onClick={(e) => {
          if (e.target === dialogRef.current) {
            onClose();
          }
        }}
      >
        {preview && (
          <>
            <div className="pdf-preview-head">
              <h2 id="pdfPreviewTitle">Pré-visualização — {preview.title}</h2>
              <div className="pdf-preview-actions">
                {preview.type === 'production' && onChangeOperator && (
                  <select
                    aria-label="Escolher operador para impressão"
                    className="print-operator-select"
                    value={selectedOperator ?? preview.operatorFilter ?? 'all'}
                    onChange={(e) =>
                      onChangeOperator(e.target.value as PrintOperatorFilter)
                    }
                  >
                    <option value="all">Todos os operadores</option>
                    {OPERATORS.map((op) => (
                      <option key={op} value={op}>
                        {op}
                      </option>
                    ))}
                  </select>
                )}
                {preview.type === 'coils-monthly' &&
                  onChangeMonth &&
                  preview.availableMonths && (
                    <select
                      aria-label="Escolher mês do relatório mensal"
                      className="print-operator-select"
                      value={selectedMonth ?? preview.monthFilter ?? ''}
                      onChange={(e) => onChangeMonth(e.target.value)}
                    >
                      {preview.availableMonths.map((ym) => (
                        <option key={ym} value={ym}>
                          {fmtMonthYear(ym)}
                        </option>
                      ))}
                    </select>
                  )}
                <button
                  className="btn secondary small"
                  type="button"
                  onClick={() => {
                    preview.doc.save(preview.filename);
                    onNotify(preview.downloadSuccessMessage);
                  }}
                >
                  Baixar PDF
                </button>
                <button
                  className="btn small"
                  type="button"
                  onClick={handlePrint}
                >
                  Imprimir
                </button>
                <button
                  className="btn secondary small"
                  type="button"
                  onClick={onClose}
                >
                  Fechar
                </button>
              </div>
            </div>
            <div className="pdf-preview-scroll">
              <ReportDocument preview={preview} />
            </div>
          </>
        )}
      </dialog>

      {preview && printAreaEl
        ? createPortal(<ReportDocument preview={preview} />, printAreaEl)
        : null}
    </>
  );
}
