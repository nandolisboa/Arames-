import { Search } from 'lucide-react';
import { useMemo, useState, type ReactNode } from 'react';
import {
  COILS_PAGE_SIZE,
  GAUGES,
  fmtDate,
  fmtKg,
  fmtMonthYear,
  fmtTimeFromIso,
  gaugeTextClass,
  localDateFromIso,
  today,
} from '../constants';
import { formatCoilWeights } from '../lib/coilWeights';
import {
  createCoilsMonthlyPdfPreview,
  createCoilsPdfPreview,
  downloadCoilsPDF,
  formatWeightSourceLabel,
  type PdfPreviewData,
} from '../lib/reports';
import type { CoilRow } from '../types';
import { ConfirmDialog } from './ConfirmDialog';
import { PdfPreviewDialog } from './PdfPreviewDialog';

interface CoilsPanelProps {
  visible: boolean;
  isAdmin: boolean;
  canSeeCoils: boolean;
  coilsLoaded: boolean;
  coilsLoading: boolean;
  coilsError: string;
  coilRows: CoilRow[];
  onSaveCoil: (payload: {
    gauge: string;
    manufacturer: string;
    weight_kg: number;
    weight_label_kg: number | null;
    weight_scale_kg: number | null;
    weight_source: string;
    invoice_number: string;
    invoice_series: string | null;
  }) => Promise<boolean>;
  onDeleteCoil: (id: string | number) => Promise<void>;
  onNotify: (msg: string) => void;
}

function formatMobileCoilWeight(c: CoilRow): ReactNode {
  if (
    c.weight_source === 'AMBOS' &&
    c.weight_label_kg != null &&
    c.weight_scale_kg != null
  ) {
    return (
      <>
        {formatCoilWeights(c)
          .split(' / ')
          .map((weight) => (
            <div key={weight}>
              {weight.replace('Etiqueta:', 'Etiq.').replace('Balança:', 'Bal.')}
            </div>
          ))}
      </>
    );
  }
  if (c.weight_source === 'AMBOS') {
    if (c.weight_label_kg != null) {
      return `Etiq. ${formatCoilWeights(c)}`;
    }
    if (c.weight_scale_kg != null) {
      return `Bal. ${formatCoilWeights(c)}`;
    }
    return formatCoilWeights(c);
  }
  const prefix = c.weight_source === 'ETIQUETA' ? 'Etiq.' : 'Bal.';
  return `${prefix} ${formatCoilWeights(c)}`;
}

export function CoilsPanel({
  visible,
  isAdmin,
  canSeeCoils,
  coilsLoaded,
  coilsLoading,
  coilsError,
  coilRows,
  onSaveCoil,
  onDeleteCoil,
  onNotify,
}: CoilsPanelProps) {
  const [coilGauge, setCoilGauge] = useState('');
  const [coilManufacturer, setCoilManufacturer] = useState('');
  const [labelWeight, setLabelWeight] = useState('');
  const [scaleWeight, setScaleWeight] = useState('');
  const [coilSource, setCoilSource] = useState('ETIQUETA');
  const [coilInvoiceNumber, setCoilInvoiceNumber] = useState('');
  const [coilInvoiceSeries, setCoilInvoiceSeries] = useState('');
  const [coilSearch, setCoilSearch] = useState('');
  const [coilMonthFilter, setCoilMonthFilter] = useState<string>('all');
  const [reportMonth, setReportMonth] = useState<string>(() =>
    today().slice(0, 7)
  );
  const [page, setPage] = useState(0);
  const [expandedDays, setExpandedDays] = useState<Record<string, boolean>>({});
  const [searchExpandedDays, setSearchExpandedDays] = useState<
    Record<string, boolean>
  >({});
  const [saving, setSaving] = useState(false);
  const [mobileView, setMobileView] = useState<'form' | 'list'>('list');

  const [pendingDeleteCoil, setPendingDeleteCoil] = useState<CoilRow | null>(null);
  const [pdfPreview, setPdfPreview] = useState<PdfPreviewData | null>(null);

  const availableMonths = useMemo(() => {
    const months = new Set<string>([today().slice(0, 7)]);
    for (const c of coilRows) {
      const ym = localDateFromIso(c.created_at).slice(0, 7);
      if (/^\d{4}-\d{2}$/.test(ym)) months.add(ym);
    }
    return Array.from(months).sort((a, b) => b.localeCompare(a));
  }, [coilRows]);

  const activeReportMonth = availableMonths.includes(reportMonth)
    ? reportMonth
    : availableMonths[0] || today().slice(0, 7);

  const filteredCoils = useMemo(() => {
    const query = coilSearch.trim().toLocaleLowerCase('pt-BR');
    return coilRows.filter((c) => {
      const regDate = localDateFromIso(c.created_at);
      if (
        coilMonthFilter !== 'all' &&
        regDate.slice(0, 7) !== coilMonthFilter
      ) {
        return false;
      }
      if (!query) return true;
      const formattedDate = fmtDate(regDate);
      return [
        c.invoice_number,
        c.invoice_series,
        c.manufacturer,
        c.gauge,
        formattedDate,
      ].some((v) =>
        String(v || '')
          .toLocaleLowerCase('pt-BR')
          .includes(query)
      );
    });
  }, [coilRows, coilSearch, coilMonthFilter]);

  const dayGroups = useMemo(() => {
    const map = new Map<string, CoilRow[]>();
    for (const c of filteredCoils) {
      const day = localDateFromIso(c.created_at) || 'Sem data';
      const list = map.get(day);
      if (list) list.push(c);
      else map.set(day, [c]);
    }
    return Array.from(map.entries())
      .sort(([a], [b]) => b.localeCompare(a))
      .map(([date, coils]) => ({
        date,
        coils,
        totalKg: coils.reduce((sum, c) => sum + Number(c.weight_kg || 0), 0),
      }));
  }, [filteredCoils]);

  const pageCount = Math.max(1, Math.ceil(dayGroups.length / COILS_PAGE_SIZE));
  const currentPage = Math.min(page, pageCount - 1);
  const shownDayGroups = useMemo(
    () =>
      dayGroups.slice(
        currentPage * COILS_PAGE_SIZE,
        (currentPage + 1) * COILS_PAGE_SIZE
      ),
    [dayGroups, currentPage]
  );

  const hasSearch = coilSearch.trim().length > 0;

  const handleSave = async () => {
    if (!isAdmin) return;
    const manufacturer = coilManufacturer.trim();
    const parseWeight = (text: string) => {
      const normalized = text.trim().replace(',', '.');
      const n = Number(normalized);
      return /^[0-9]+(?:\.[0-9]{1,3})?$/.test(normalized) && n > 0 && n <= 100000
        ? n
        : null;
    };
    const label = parseWeight(labelWeight);
    const scale = parseWeight(scaleWeight);
    const weight = coilSource === 'BALANCA' ? scale : label;
    const invoiceNumber = coilInvoiceNumber.trim();
    const invoiceSeries = coilInvoiceSeries.trim();

    if (
      !GAUGES.includes(coilGauge as (typeof GAUGES)[number]) ||
      !manufacturer ||
      manufacturer.length > 80 ||
      weight === null ||
      (coilSource === 'AMBOS' && (label === null || scale === null)) ||
      !['ETIQUETA', 'BALANCA', 'AMBOS'].includes(coilSource) ||
      !invoiceNumber ||
      invoiceNumber.length > 40 ||
      invoiceSeries.length > 20
    ) {
      onNotify('Preencha os dados da bobina e informe o número da nota fiscal');
      return;
    }

    setSaving(true);
    try {
      const ok = await onSaveCoil({
        gauge: coilGauge,
        manufacturer,
        weight_kg: weight,
        weight_label_kg: coilSource === 'BALANCA' ? null : label,
        weight_scale_kg: coilSource === 'ETIQUETA' ? null : scale,
        weight_source: coilSource,
        invoice_number: invoiceNumber,
        invoice_series: invoiceSeries || null,
      });
      if (ok) {
        setCoilGauge('');
        setCoilManufacturer('');
        setLabelWeight('');
        setScaleWeight('');
        setCoilSource('ETIQUETA');
        setCoilInvoiceNumber('');
        setCoilInvoiceSeries('');
        setPage(0);
      }
    } finally {
      setSaving(false);
    }
  };

  const buildActiveFilterNote = (): string | undefined => {
    const parts: string[] = [];
    if (coilMonthFilter !== 'all') {
      parts.push(`Mês: ${fmtMonthYear(coilMonthFilter)}`);
    }
    const trimmedQuery = coilSearch.trim();
    if (trimmedQuery) {
      parts.push(`Busca: "${trimmedQuery}"`);
    }
    return parts.length ? parts.join(' • ') : undefined;
  };

  const handlePdf = (print: boolean) => {
    if (!canSeeCoils) return;
    if (!coilsLoaded) {
      onNotify('Aguarde as bobinas carregarem antes de gerar o PDF.');
      return;
    }
    const filterNote = buildActiveFilterNote();
    if (print) {
      const preview = createCoilsPdfPreview(filteredCoils, onNotify, filterNote);
      if (preview) setPdfPreview(preview);
    } else {
      downloadCoilsPDF(filteredCoils, onNotify, filterNote);
    }
  };

  const handleOpenMonthlyReport = () => {
    if (!canSeeCoils) return;
    if (!coilsLoaded) {
      onNotify('Aguarde as bobinas carregarem antes de gerar o relatório.');
      return;
    }
    const preview = createCoilsMonthlyPdfPreview(
      coilRows,
      activeReportMonth,
      availableMonths,
      onNotify
    );
    if (preview) setPdfPreview(preview);
  };

  if (!visible) return null;

  return (
    <section id="coilsPanel">
      {isAdmin && (
        <div
          aria-label="Alternar entre cadastro e lista de bobinas"
          className="mobile-view-switch"
          role="tablist"
        >
          <button
            aria-selected={mobileView === 'list'}
            className={`mobile-view-btn${mobileView === 'list' ? ' active' : ''}`}
            role="tab"
            type="button"
            onClick={() => setMobileView('list')}
          >
            Bobinas ({filteredCoils.length})
          </button>
          <button
            aria-selected={mobileView === 'form'}
            className={`mobile-view-btn${mobileView === 'form' ? ' active' : ''}`}
            role="tab"
            type="button"
            onClick={() => setMobileView('form')}
          >
            Cadastrar
          </button>
        </div>
      )}

      {isAdmin && (
        <section
          className={`card${mobileView !== 'form' ? ' mobile-pane-hidden' : ''}`}
          id="coilFormCard"
        >
          <h2>Cadastrar bobina</h2>
          <div className="coil-form">
            <div className="field">
              <label htmlFor="coilGauge">Bobina (mm)</label>
              <button
                aria-label={`Bobina (mm): ${coilGauge || 'não selecionada'}. Toque para mudar.`}
                aria-required="true"
                className={`btn secondary gauge-toggle ${gaugeTextClass(coilGauge)}`}
                id="coilGauge"
                type="button"
                onClick={() => {
                  const currentIndex = GAUGES.indexOf(
                    coilGauge as (typeof GAUGES)[number]
                  );
                  setCoilGauge(GAUGES[(currentIndex + 1) % GAUGES.length]);
                }}
              >
                {coilGauge || 'Selecione'}
              </button>
            </div>
            <div className="field coil-maker-field">
              <label htmlFor="coilManufacturer">Fabricante</label>
              <input
                autoComplete="off"
                id="coilManufacturer"
                maxLength={80}
                placeholder="Fabricante"
                type="text"
                value={coilManufacturer}
                onChange={(e) => setCoilManufacturer(e.target.value)}
              />
            </div>
            {(coilSource === 'ETIQUETA' || coilSource === 'AMBOS') && (
              <div className="field">
                <label htmlFor="coilWeightLabel">Peso etiqueta (kg)</label>
                <input
                  id="coilWeightLabel"
                  inputMode="decimal"
                  maxLength={12}
                  placeholder="0,000"
                  type="text"
                  value={labelWeight}
                  onChange={(e) => setLabelWeight(e.target.value)}
                />
              </div>
            )}
            {(coilSource === 'BALANCA' || coilSource === 'AMBOS') && (
              <div className="field">
                <label htmlFor="coilWeightScale">Peso balança (kg)</label>
                <input
                  id="coilWeightScale"
                  inputMode="decimal"
                  maxLength={12}
                  placeholder="0,000"
                  type="text"
                  value={scaleWeight}
                  onChange={(e) => setScaleWeight(e.target.value)}
                />
              </div>
            )}
            <div className="field">
              <label htmlFor="coilSource">Peso informado por</label>
              <button
                aria-label={`Peso informado por: ${formatWeightSourceLabel(coilSource)}. Toque para mudar.`}
                className="btn secondary"
                id="coilSource"
                type="button"
                onClick={() =>
                  setCoilSource((source) =>
                    source === 'ETIQUETA'
                      ? 'BALANCA'
                      : source === 'BALANCA'
                        ? 'AMBOS'
                        : 'ETIQUETA'
                  )
                }
              >
                {formatWeightSourceLabel(coilSource)}
              </button>
            </div>
            <div className="field">
              <label htmlFor="coilInvoiceNumber">Nº da nota fiscal</label>
              <input
                id="coilInvoiceNumber"
                maxLength={40}
                placeholder="Número da NF"
                type="text"
                value={coilInvoiceNumber}
                onChange={(e) => setCoilInvoiceNumber(e.target.value)}
              />
            </div>
            <div className="field">
              <label htmlFor="coilInvoiceSeries">Série</label>
              <input
                id="coilInvoiceSeries"
                maxLength={20}
                placeholder="Série (opcional)"
                type="text"
                value={coilInvoiceSeries}
                onChange={(e) => setCoilInvoiceSeries(e.target.value)}
              />
            </div>
          </div>
          <div className="actions">
            <button
              className="btn"
              disabled={saving}
              id="saveCoilBtn"
              type="button"
              onClick={() => void handleSave()}
            >
              {saving ? 'Salvando…' : 'Salvar bobina'}
            </button>
          </div>
        </section>
      )}

      <section
        className={`card${isAdmin && mobileView !== 'list' ? ' mobile-pane-hidden' : ''}`}
      >
        <div className="sectionhead">
          <h2>Bobinas salvas por dia</h2>
          <div className="tools">
            <select
              aria-label="Mês para relatório mensal de bobinas"
              className="print-operator-select"
              id="coilReportMonthSelect"
              value={activeReportMonth}
              onChange={(e) => setReportMonth(e.target.value)}
            >
              {availableMonths.map((ym) => (
                <option key={ym} value={ym}>
                  {fmtMonthYear(ym)}
                </option>
              ))}
            </select>
            <button
              className="btn secondary small"
              id="monthlyCoilsReportBtn"
              type="button"
              onClick={handleOpenMonthlyReport}
            >
              Relatório mensal
            </button>
            <button
              className="btn secondary small"
              id="pdfCoilsBtn"
              type="button"
              onClick={() => handlePdf(false)}
            >
              PDF
            </button>
            <button
              className="btn secondary small"
              id="printCoilsBtn"
              type="button"
              onClick={() => handlePdf(true)}
            >
              Imprimir
            </button>
          </div>
        </div>

        <div className="production-filters-bar">
          <div className="field coil-search-field search-input-wrap">
            <Search aria-hidden="true" className="search-icon" size={16} />
            <input
              aria-label="Buscar bobina por data, NF, série, fabricante ou bitola"
              id="coilSearch"
              maxLength={80}
              placeholder="Buscar: data, NF, série, fabricante ou bitola"
              type="search"
              value={coilSearch}
              onChange={(e) => {
                setCoilSearch(e.target.value);
                setPage(0);
                setSearchExpandedDays({});
              }}
            />
          </div>
          <select
            aria-label="Filtrar lista de bobinas por mês"
            className="coil-month-filter"
            id="coilMonthFilter"
            value={coilMonthFilter}
            onChange={(e) => {
              setCoilMonthFilter(e.target.value);
              setPage(0);
              setSearchExpandedDays({});
            }}
          >
            <option value="all">Todos os meses</option>
            {availableMonths.map((ym) => (
              <option key={ym} value={ym}>
                {fmtMonthYear(ym)}
              </option>
            ))}
          </select>
        </div>

        {coilsLoading ? (
          <div className="empty" id="coilsRecords">
            Carregando bobinas…
          </div>
        ) : coilsError ? (
          <div className="empty" id="coilsRecords">
            {coilsError}
          </div>
        ) : !coilRows.length ? (
          <div className="empty" id="coilsRecords">
            Nenhuma bobina cadastrada.
          </div>
        ) : !filteredCoils.length ? (
          <div className="empty" id="coilsRecords">
            Nenhuma bobina encontrada para essa busca.
          </div>
        ) : (
          <div className="groups" id="coilsRecords">
            {shownDayGroups.map((group) => {
              const dateLabel =
                group.date === 'Sem data' ? 'Sem data' : fmtDate(group.date);
              const isExpanded = hasSearch
                ? searchExpandedDays[group.date] !== false
                : !!expandedDays[group.date];

              return (
                <section key={group.date} className="operator">
                  <button
                    aria-expanded={isExpanded}
                    className="operator-title operator-toggle"
                    type="button"
                    onClick={() => {
                      if (hasSearch) {
                        setSearchExpandedDays((prev) => ({
                          ...prev,
                          [group.date]: prev[group.date] === false,
                        }));
                      } else {
                        setExpandedDays((prev) => ({
                          ...prev,
                          [group.date]: !prev[group.date],
                        }));
                      }
                    }}
                  >
                    <span className="presence-name">
                      <span className="operator-btn-label">{dateLabel}</span>
                      <span aria-hidden="true" className="operator-chevron">
                        {isExpanded ? '▾' : '▸'}
                      </span>
                    </span>
                    <span className="count">
                      {group.coils.length}{' '}
                      {group.coils.length === 1 ? 'bobina' : 'bobinas'} •{' '}
                      {fmtKg(group.totalKg)}
                    </span>
                  </button>

                  {isExpanded && (
                    <>
                      <div className="coils-table-wrap">
                        <table className="coils-table">
                          <thead>
                            <tr>
                              <th>Hora</th>
                              <th>Bobina</th>
                              <th>Fabricante</th>
                              <th>NF</th>
                              <th>Série</th>
                              <th className="num">Peso (kg)</th>
                              <th>Origem do peso</th>
                              {isAdmin && <th />}
                            </tr>
                          </thead>
                          <tbody>
                            {group.coils.map((c) => {
                              const timeStr = fmtTimeFromIso(c.created_at);
                              return (
                                <tr key={c.id}>
                                  <td>{timeStr || '—'}</td>
                                  <td>
                                    <strong className={gaugeTextClass(c.gauge)}>
                                      {c.gauge} mm
                                    </strong>
                                  </td>
                                  <td>{c.manufacturer}</td>
                                  <td>{c.invoice_number || '—'}</td>
                                  <td>{c.invoice_series || '—'}</td>
                                  <td className="num">
                                    {formatCoilWeights(c)}
                                  </td>
                                  <td>
                                    {formatWeightSourceLabel(c.weight_source)}
                                  </td>
                                  {isAdmin && (
                                    <td className="saved-actions">
                                      <button
                                        className="btn danger small"
                                        type="button"
                                        onClick={() => setPendingDeleteCoil(c)}
                                      >
                                        Apagar
                                      </button>
                                    </td>
                                  )}
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                      <div className="mobile-record-list">
                        {group.coils.map((c) => {
                          const timeStr = fmtTimeFromIso(c.created_at);
                          return (
                            <article key={c.id} className="mobile-record-card">
                              <div
                                className={
                                  c.weight_source === 'AMBOS'
                                    ? 'mobile-record-top mobile-coil-both'
                                    : 'mobile-record-top'
                                }
                              >
                                <div className="mobile-record-main">
                                  <strong
                                    className={`mobile-record-gauge ${gaugeTextClass(c.gauge)}`}
                                  >
                                    {c.gauge} mm
                                  </strong>
                                  <span aria-hidden="true" className="meta-sep">
                                    ·
                                  </span>
                                  <span className="mobile-record-measure">
                                    {c.manufacturer}
                                  </span>
                                </div>
                                <div className="mobile-record-total">
                                  {formatMobileCoilWeight(c)}
                                </div>
                              </div>
                              <div className="mobile-record-bottom">
                                <div className="mobile-record-meta">
                                  {timeStr && (
                                    <>
                                      <span>{timeStr}</span>
                                      <span
                                        aria-hidden="true"
                                        className="meta-sep"
                                      >
                                        ·
                                      </span>
                                    </>
                                  )}
                                  <span>NF {c.invoice_number || '—'}</span>
                                  <span aria-hidden="true" className="meta-sep">
                                    ·
                                  </span>
                                  <span>Série {c.invoice_series || '—'}</span>
                                  <span aria-hidden="true" className="meta-sep">
                                    ·
                                  </span>
                                  <span>
                                    {formatWeightSourceLabel(c.weight_source)}
                                  </span>
                                </div>
                                {isAdmin && (
                                  <div className="mobile-record-actions">
                                    <button
                                      className="btn danger small"
                                      type="button"
                                      onClick={() => setPendingDeleteCoil(c)}
                                    >
                                      Apagar
                                    </button>
                                  </div>
                                )}
                              </div>
                            </article>
                          );
                        })}
                      </div>
                    </>
                  )}
                </section>
              );
            })}

            {pageCount > 1 && (
              <div className="pager">
                <button
                  className="btn secondary small"
                  disabled={currentPage === 0}
                  type="button"
                  onClick={() => setPage((p) => Math.max(0, p - 1))}
                >
                  Anterior
                </button>
                <span>
                  {currentPage * COILS_PAGE_SIZE + 1}–
                  {Math.min(
                    (currentPage + 1) * COILS_PAGE_SIZE,
                    dayGroups.length
                  )}{' '}
                  de {dayGroups.length} dias
                </span>
                <button
                  className="btn secondary small"
                  disabled={currentPage >= pageCount - 1}
                  type="button"
                  onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))}
                >
                  Próxima
                </button>
              </div>
            )}
          </div>
        )}
      </section>

      <PdfPreviewDialog
        preview={pdfPreview}
        selectedMonth={
          pdfPreview?.type === 'coils-monthly' ? activeReportMonth : undefined
        }
        onChangeMonth={
          pdfPreview?.type === 'coils-monthly'
            ? (nextMonth) => {
                setReportMonth(nextMonth);
                const nextPreview = createCoilsMonthlyPdfPreview(
                  coilRows,
                  nextMonth,
                  availableMonths,
                  onNotify
                );
                if (nextPreview) setPdfPreview(nextPreview);
              }
            : undefined
        }
        onClose={() => setPdfPreview(null)}
        onNotify={onNotify}
      />

      <ConfirmDialog
        message={
          pendingDeleteCoil
            ? `Apagar a bobina ${pendingDeleteCoil.gauge} mm — ${pendingDeleteCoil.manufacturer}?`
            : ''
        }
        open={!!pendingDeleteCoil}
        onCancel={() => setPendingDeleteCoil(null)}
        onConfirm={() => {
          const target = pendingDeleteCoil;
          setPendingDeleteCoil(null);
          if (target) {
            void onDeleteCoil(target.id);
          }
        }}
      />
    </section>
  );
}
