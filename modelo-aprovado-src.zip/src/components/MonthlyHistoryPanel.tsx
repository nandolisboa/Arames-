import { CalendarCheck2, FileText, Search } from 'lucide-react';
import { useMemo, useState } from 'react';
import {
  GAUGES,
  MESSAGES,
  OPERATORS,
  PAGE_SIZE,
  fmtDate,
  fmtMonthYear,
  gaugeTextClass,
  nextMonthFirstDay,
  rowDate,
} from '../constants';
import {
  createProductionPdfPreview,
  type PdfPreviewData,
  type PrintOperatorFilter,
} from '../lib/reports';
import type {
  AppProfile,
  GoalTargets,
  OperatorName,
  ProductionRow,
} from '../types';
import { PdfPreviewDialog } from './PdfPreviewDialog';

interface MonthlyHistoryPanelProps {
  visible: boolean;
  allRows: ProductionRow[];
  profile: AppProfile | null;
  readAll: boolean;
  goalTargets: GoalTargets;
  currentMonth: string;
  loadingRows: boolean;
  loadError: string;
  onRetryLoad: () => void;
  onNotify: (msg: string) => void;
}

interface ClosedMonthGroup {
  month: string;
  label: string;
  closedOn: string;
  rows: ProductionRow[];
  totalPieces: number;
  byOperator: Record<string, number>;
  byGauge: { gauge: string; pieces: number }[];
}

export function MonthlyHistoryPanel({
  visible,
  allRows,
  profile,
  readAll,
  goalTargets,
  currentMonth,
  loadingRows,
  loadError,
  onRetryLoad,
  onNotify,
}: MonthlyHistoryPanelProps) {
  const [selectedMonth, setSelectedMonth] = useState<string>('all');
  const [historySearch, setHistorySearch] = useState('');
  const [expandedMonths, setExpandedMonths] = useState<Record<string, boolean>>(
    {}
  );
  const [expandedMonthOps, setExpandedMonthOps] = useState<
    Record<string, boolean>
  >({});
  const [pages, setPages] = useState<Record<string, number>>({});
  const [printOperator, setPrintOperator] = useState<PrintOperatorFilter>('all');
  const [pdfContext, setPdfContext] = useState<{
    month: string;
    closedOn: string;
    rows: ProductionRow[];
    preview: PdfPreviewData;
  } | null>(null);

  const closedAllRows = useMemo(
    () =>
      allRows.filter((r) => {
        const ym = rowDate(r.production_date).slice(0, 7);
        return /^\d{4}-\d{2}$/.test(ym) && ym < currentMonth;
      }),
    [allRows, currentMonth]
  );

  const availableClosedMonths = useMemo(() => {
    const set = new Set<string>();
    for (const r of closedAllRows) {
      set.add(rowDate(r.production_date).slice(0, 7));
    }
    return Array.from(set).sort((a, b) => b.localeCompare(a));
  }, [closedAllRows]);

  const effectiveSelectedMonth =
    selectedMonth === 'all' || availableClosedMonths.includes(selectedMonth)
      ? selectedMonth
      : 'all';

  const filteredClosedRows = useMemo(() => {
    const byMonth =
      effectiveSelectedMonth === 'all'
        ? closedAllRows
        : closedAllRows.filter(
            (r) => rowDate(r.production_date).slice(0, 7) === effectiveSelectedMonth
          );

    const tokens = historySearch
      .trim()
      .toLocaleLowerCase('pt-BR')
      .split(/\s+/)
      .filter(Boolean);
    if (!tokens.length) return byMonth;

    return byMonth.filter((r) => {
      const rawDate = rowDate(r.production_date);
      const formattedDate = fmtDate(rawDate);
      const haystack = [
        r.operator,
        formattedDate,
        rawDate,
        r.measure,
        r.gauge,
        `${r.gauge} mm`,
        r.package_type,
        String(r.pieces_per_unit),
        Number(r.pieces_per_unit).toLocaleString('pt-BR'),
        String(r.units),
        Number(r.units).toLocaleString('pt-BR'),
        String(r.total_pieces),
        Number(r.total_pieces).toLocaleString('pt-BR'),
      ]
        .join(' ')
        .toLocaleLowerCase('pt-BR');

      return tokens.every((token) => haystack.includes(token));
    });
  }, [closedAllRows, effectiveSelectedMonth, historySearch]);

  const monthGroups = useMemo<ClosedMonthGroup[]>(() => {
    const map = new Map<string, ProductionRow[]>();
    for (const r of filteredClosedRows) {
      const ym = rowDate(r.production_date).slice(0, 7);
      const list = map.get(ym);
      if (list) list.push(r);
      else map.set(ym, [r]);
    }

    return Array.from(map.entries())
      .sort(([a], [b]) => b.localeCompare(a))
      .map(([month, rows]) => {
        const byOperator: Record<string, number> = {};
        const gaugeMap = new Map<string, number>();
        let totalPieces = 0;

        for (const r of rows) {
          const pcs = Number(r.total_pieces || 0);
          totalPieces += pcs;
          byOperator[r.operator] = (byOperator[r.operator] || 0) + pcs;
          const g = String(r.gauge || '');
          gaugeMap.set(g, (gaugeMap.get(g) || 0) + pcs);
        }

        const orderedGauges = [
          ...GAUGES.filter((g) => gaugeMap.has(g)),
          ...Array.from(gaugeMap.keys()).filter(
            (g) => !GAUGES.includes(g as (typeof GAUGES)[number])
          ),
        ];

        return {
          month,
          label: fmtMonthYear(month),
          closedOn: nextMonthFirstDay(month),
          rows,
          totalPieces,
          byOperator,
          byGauge: orderedGauges.map((g) => ({
            gauge: g,
            pieces: gaugeMap.get(g) || 0,
          })),
        };
      });
  }, [filteredClosedRows]);

  if (!visible) return null;

  const opsToRender = readAll
    ? OPERATORS
    : profile?.display_name
      ? [profile.display_name]
      : [];

  const hasSearch = historySearch.trim().length > 0;

  const openMonthPdf = (
    group: ClosedMonthGroup,
    nextOp: PrintOperatorFilter = printOperator
  ) => {
    const filterParts = [`Mês de referência: ${group.label}`];
    if (hasSearch) filterParts.push(`Busca: "${historySearch.trim()}"`);

    const preview = createProductionPdfPreview(
      group.rows,
      onNotify,
      readAll ? nextOp : 'all',
      filterParts.join(' • '),
      {
        titleBase: `${MESSAGES.monthlyClosingTitle} — ${group.label}`,
        filenamePrefix: `resumo_mensal_${group.month}`,
      }
    );
    if (preview) {
      setPdfContext({
        month: group.month,
        closedOn: group.closedOn,
        rows: group.rows,
        preview,
      });
    }
  };

  return (
    <section className="card history-panel" id="historyPanel">
      <div className="sectionhead history-sectionhead">
        <div>
          <h2>Histórico mensal de produção</h2>
          <p className="history-subtitle">
            Os meses anteriores são organizados a partir dos lançamentos existentes e separados de {fmtMonthYear(currentMonth)}. Este histórico é calculado; não representa um snapshot imutável.
          </p>
        </div>
        {availableClosedMonths.length > 0 && (
          <span className="history-count-badge">
            {availableClosedMonths.length}{' '}
            {availableClosedMonths.length === 1 ? 'mês anterior' : 'meses anteriores'}
          </span>
        )}
      </div>

      {availableClosedMonths.length > 0 && (
        <div className="production-filters-bar history-filters-bar">
          <div className="field coil-search-field search-input-wrap">
            <Search aria-hidden="true" className="search-icon" size={16} />
            <input
              aria-label="Pesquisar no histórico mensal"
              id="historySearch"
              maxLength={120}
              placeholder="Buscar no histórico: operador, data, estribo ou bitola"
              type="search"
              value={historySearch}
              onChange={(e) => {
                setHistorySearch(e.target.value);
                setPages({});
              }}
            />
          </div>

          <select
            aria-label="Filtrar mês anterior"
            className="coil-month-filter"
            id="historyMonthFilter"
            value={effectiveSelectedMonth}
            onChange={(e) => {
              setSelectedMonth(e.target.value);
              setPages({});
            }}
          >
            <option value="all">Todos os meses anteriores</option>
            {availableClosedMonths.map((ym) => (
              <option key={ym} value={ym}>
                {fmtMonthYear(ym)}
              </option>
            ))}
          </select>
        </div>
      )}

      {loadingRows ? (
        <div className="empty">Carregando histórico mensal…</div>
      ) : loadError ? (
        <div className="empty load-error" role="alert">
          <p>{loadError}</p>
          <button
            className="btn secondary small"
            type="button"
            onClick={onRetryLoad}
          >
            Tentar novamente
          </button>
        </div>
      ) : !availableClosedMonths.length ? (
        <div className="empty history-empty-box">
          <strong>Nenhum registro de meses anteriores ainda.</strong>
          <p>
            Os registros de {fmtMonthYear(currentMonth)} ficam na aba Produção. A partir de {nextMonthFirstDay(currentMonth)}, os registros desse mês serão agrupados aqui com base nos dados existentes.
          </p>
        </div>
      ) : !monthGroups.length ? (
        <div className="empty">
          Nenhum registro encontrado no histórico para a busca informada.
        </div>
      ) : (
        <div className="history-months-list">
          {monthGroups.map((group) => {
            const isMonthExpanded = hasSearch || !!expandedMonths[group.month];

            return (
              <article key={group.month} className="history-month-card">
                <div className="history-month-head">
                  <div className="history-month-title-wrap">
                    <div className="history-month-title-row">
                      <h3>{group.label}</h3>
                      <span className="history-closing-badge">
                        <CalendarCheck2 aria-hidden="true" size={14} />
                        <span>Período até {group.closedOn}</span>
                      </span>
                    </div>
                    <div className="history-month-meta">
                      <span>
                        {group.rows.length}{' '}
                        {group.rows.length === 1 ? 'registro' : 'registros'}
                      </span>
                      <span aria-hidden="true" className="meta-sep">
                        ·
                      </span>
                      <strong>
                        {group.totalPieces.toLocaleString('pt-BR')} peças
                      </strong>
                    </div>
                  </div>

                  <div className="history-month-actions">
                    <button
                      aria-expanded={isMonthExpanded}
                      className="btn secondary small"
                      type="button"
                      onClick={() =>
                        setExpandedMonths((prev) => ({
                          ...prev,
                          [group.month]: !prev[group.month],
                        }))
                      }
                    >
                      {isMonthExpanded ? 'Ocultar registros' : 'Ver registros'}
                    </button>
                    <button
                      className="btn small history-pdf-btn"
                      type="button"
                      onClick={() => openMonthPdf(group)}
                    >
                      <FileText aria-hidden="true" size={14} />
                      <span>Imprimir / PDF</span>
                    </button>
                  </div>
                </div>

                <div className="history-summary-strip">
                  <div className="history-ops-grid">
                    {opsToRender.map((op) => {
                      const pieces = group.byOperator[op] || 0;
                      const goal = Number(
                        goalTargets[op as OperatorName] || 100000
                      );
                      const pct = goal > 0 ? Math.floor((pieces / goal) * 100) : 0;
                      return (
                        <div key={op} className="history-op-chip">
                          <span className="history-op-name">{op}</span>
                          <strong className="history-op-total">
                            {pieces.toLocaleString('pt-BR')} pç
                          </strong>
                          <span className="history-op-pct">{pct}% da meta</span>
                        </div>
                      );
                    })}
                  </div>

                  {group.byGauge.length > 0 && (
                    <div className="history-gauges-row">
                      {group.byGauge.map((g) => (
                        <span key={g.gauge} className="history-gauge-pill">
                          <strong className={gaugeTextClass(g.gauge)}>
                            {g.gauge} mm
                          </strong>
                          <span>{g.pieces.toLocaleString('pt-BR')} pç</span>
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {isMonthExpanded && (
                  <div className="history-records-body">
                    <div className="groups">
                      {opsToRender.map((op) => {
                        const list = group.rows.filter((r) => r.operator === op);
                        if (!list.length) return null;
                        const opKey = `${group.month}:${op}`;
                        const pageCount = Math.max(
                          1,
                          Math.ceil(list.length / PAGE_SIZE)
                        );
                        const currentPage = Math.min(
                          pages[opKey] || 0,
                          pageCount - 1
                        );
                        const shown = list.slice(
                          currentPage * PAGE_SIZE,
                          (currentPage + 1) * PAGE_SIZE
                        );
                        const sum = list.reduce(
                          (acc, r) => acc + Number(r.total_pieces),
                          0
                        );
                        const isOpExpanded =
                          hasSearch ||
                          opsToRender.length === 1 ||
                          expandedMonthOps[opKey] !== false;

                        return (
                          <section key={opKey} className="operator">
                            <button
                              aria-expanded={isOpExpanded}
                              className="operator-title operator-toggle"
                              type="button"
                              onClick={() =>
                                setExpandedMonthOps((prev) => ({
                                  ...prev,
                                  [opKey]: prev[opKey] === false,
                                }))
                              }
                            >
                              <span className="presence-name">
                                <span className="operator-btn-label">{op}</span>
                                <span aria-hidden="true" className="operator-chevron">
                                  {isOpExpanded ? '▾' : '▸'}
                                </span>
                              </span>
                              <span className="count">
                                {sum.toLocaleString('pt-BR')} peças
                              </span>
                            </button>

                            {isOpExpanded && (
                              <>
                                <div className="saved-table-wrap">
                                  <table className="saved-table">
                                    <thead>
                                      <tr>
                                        <th>DATA</th>
                                        <th>ESTRIBO / MEDIDA</th>
                                        <th>TIPO</th>
                                        <th className="num">PÇ/UNID.</th>
                                        <th className="num">UNIDADES</th>
                                        <th className="num">TOTAL PÇ</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {shown.map((r) => (
                                        <tr key={r.id}>
                                          <td>
                                            {fmtDate(rowDate(r.production_date))}
                                          </td>
                                          <td>
                                            <span className="saved-dimension">
                                              {r.measure || '—'}
                                            </span>
                                            <span
                                              className={`saved-measure ${gaugeTextClass(r.gauge)}`}
                                            >
                                              {r.gauge} mm
                                            </span>
                                          </td>
                                          <td>{r.package_type}</td>
                                          <td className="num">
                                            {Number(
                                              r.pieces_per_unit
                                            ).toLocaleString('pt-BR')}
                                          </td>
                                          <td className="num">
                                            {Number(r.units).toLocaleString(
                                              'pt-BR'
                                            )}
                                          </td>
                                          <td className="num total-cell">
                                            {Number(
                                              r.total_pieces
                                            ).toLocaleString('pt-BR')}
                                          </td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                </div>

                                <div className="mobile-record-list">
                                  {shown.map((r) => (
                                    <article
                                      key={r.id}
                                      className="mobile-record-card"
                                    >
                                      <div className="mobile-record-top">
                                        <div className="mobile-record-main">
                                          <strong className="mobile-record-measure">
                                            {r.measure || '—'}
                                          </strong>
                                          <span
                                            aria-hidden="true"
                                            className="meta-sep"
                                          >
                                            ·
                                          </span>
                                          <span
                                            className={`mobile-record-gauge ${gaugeTextClass(r.gauge)}`}
                                          >
                                            {r.gauge} mm
                                          </span>
                                        </div>
                                        <div className="mobile-record-total">
                                          {Number(
                                            r.total_pieces
                                          ).toLocaleString('pt-BR')}{' '}
                                          pç
                                        </div>
                                      </div>
                                      <div className="mobile-record-bottom">
                                        <div className="mobile-record-meta">
                                          <span>
                                            {fmtDate(rowDate(r.production_date))}
                                          </span>
                                          <span
                                            aria-hidden="true"
                                            className="meta-sep"
                                          >
                                            ·
                                          </span>
                                          <span>{r.package_type}</span>
                                          <span
                                            aria-hidden="true"
                                            className="meta-sep"
                                          >
                                            ·
                                          </span>
                                          <span>
                                            {Number(
                                              r.pieces_per_unit
                                            ).toLocaleString('pt-BR')}{' '}
                                            ×{' '}
                                            {Number(r.units).toLocaleString(
                                              'pt-BR'
                                            )}
                                          </span>
                                        </div>
                                      </div>
                                    </article>
                                  ))}
                                </div>

                                {pageCount > 1 && (
                                  <div className="pager">
                                    <button
                                      className="btn secondary small"
                                      disabled={currentPage === 0}
                                      type="button"
                                      onClick={() =>
                                        setPages((prev) => ({
                                          ...prev,
                                          [opKey]: Math.max(0, currentPage - 1),
                                        }))
                                      }
                                    >
                                      Anterior
                                    </button>
                                    <span>
                                      {currentPage * PAGE_SIZE + 1}–
                                      {Math.min(
                                        (currentPage + 1) * PAGE_SIZE,
                                        list.length
                                      )}{' '}
                                      de {list.length}
                                    </span>
                                    <button
                                      className="btn secondary small"
                                      disabled={currentPage >= pageCount - 1}
                                      type="button"
                                      onClick={() =>
                                        setPages((prev) => ({
                                          ...prev,
                                          [opKey]: Math.min(
                                            pageCount - 1,
                                            currentPage + 1
                                          ),
                                        }))
                                      }
                                    >
                                      Próxima
                                    </button>
                                  </div>
                                )}
                              </>
                            )}
                          </section>
                        );
                      })}
                    </div>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}

      <PdfPreviewDialog
        preview={pdfContext?.preview ?? null}
        selectedOperator={readAll ? printOperator : undefined}
        onChangeOperator={
          readAll && pdfContext
            ? (nextOp) => {
                setPrintOperator(nextOp);
                const preview = createProductionPdfPreview(
                  pdfContext.rows,
                  onNotify,
                  nextOp,
                  `Mês de referência: ${fmtMonthYear(pdfContext.month)}`,
                  {
                    titleBase: `${MESSAGES.monthlyClosingTitle} — ${fmtMonthYear(pdfContext.month)}`,
                    filenamePrefix: `resumo_mensal_${pdfContext.month}`,
                  }
                );
                if (preview) {
                  setPdfContext((prev) => (prev ? { ...prev, preview } : null));
                }
              }
            : undefined
        }
        onClose={() => setPdfContext(null)}
        onNotify={onNotify}
      />
    </section>
  );
}
