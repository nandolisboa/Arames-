import { useEffect, useMemo, useRef, useState } from 'react';
import {
  GAUGES,
  KINDS,
  MESSAGES,
  OPERATORS,
  fmtDate,
  fmtMonthYear,
  gaugeTextClass,
  rowDate,
  today,
  validDate,
} from '../constants';
import type { AppProfile, OperatorName, ProductionRow } from '../types';

type FormFieldId =
  | 'date'
  | 'operator'
  | 'kind'
  | 'measure'
  | 'gauge'
  | 'pieces'
  | 'units';

export interface EditProductionRequest {
  row: ProductionRow;
  seq: number;
}

interface ProductionFormProps {
  profile: AppProfile | null;
  isAdmin: boolean;
  currentMonth: string;
  mobileHidden: boolean;
  editRequest: EditProductionRequest | null;
  onCancelEdit: () => void;
  onSaveProduction: (params: {
    editingId: string | number | null;
    production_date: string;
    operator: OperatorName;
    gauge: string;
    measure: string;
    package_type: string;
    pieces_per_unit: number;
    units: number;
  }) => Promise<{ ok: boolean; savedId?: string | number }>;
  onSavedSuccess: (info: {
    wasEdit: boolean;
    operator: OperatorName;
    productionDate: string;
    gauge: string;
    measure: string;
    packageType: string;
    piecesPerUnit: number;
    units: number;
    savedId?: string | number;
  }) => void;
  onNotify: (msg: string) => void;
}

export function ProductionForm({
  profile,
  isAdmin,
  currentMonth,
  mobileHidden,
  editRequest,
  onCancelEdit,
  onSaveProduction,
  onSavedSuccess,
  onNotify,
}: ProductionFormProps) {
  const [date, setDate] = useState(today);
  const [operator, setOperator] = useState<OperatorName>('Fernando');
  const [kind, setKind] = useState<string>('PACOTE');
  const [measure, setMeasure] = useState('');
  const [gauge, setGauge] = useState<string>('3,8');
  const [pieces, setPieces] = useState('');
  const [units, setUnits] = useState('');
  const [editingId, setEditingId] = useState<string | number | null>(null);
  const [saving, setSaving] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<
    Partial<Record<FormFieldId, string>>
  >({});

  const [confirmModalOpen, setConfirmModalOpen] = useState(false);

  const dateRef = useRef<HTMLInputElement>(null);
  const operatorRef = useRef<HTMLSelectElement>(null);
  const kindRef = useRef<HTMLButtonElement>(null);
  const beforeSpecialKindRef = useRef<{ gauge: string; pieces: string } | null>(
    null
  );
  const measureRef = useRef<HTMLInputElement>(null);
  const gaugeRef = useRef<HTMLButtonElement>(null);
  const piecesRef = useRef<HTMLInputElement>(null);
  const unitsRef = useRef<HTMLInputElement>(null);
  const confirmDialogRef = useRef<HTMLDialogElement>(null);
  const confirmBtnRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (
      profile &&
      !isAdmin &&
      OPERATORS.includes(profile.display_name as OperatorName)
    ) {
      setOperator(profile.display_name as OperatorName);
    }
  }, [profile, isAdmin]);

  useEffect(() => {
    if (!editRequest || !isAdmin) return;
    const r = editRequest.row;
    beforeSpecialKindRef.current = null;
    setEditingId(r.id);
    setDate(rowDate(r.production_date));
    setOperator(r.operator as OperatorName);
    setGauge(String(r.gauge));
    setMeasure(r.measure || '');
    setKind(String(r.package_type));
    setPieces(String(r.pieces_per_unit));
    setUnits(String(r.units));
    setFieldErrors({});
  }, [editRequest, isAdmin]);

  useEffect(() => {
    if (editingId !== null) return;
    setDate((prev) => {
      if (!prev || prev.slice(0, 7) < currentMonth) return today();
      return prev;
    });
  }, [currentMonth, editingId]);

  useEffect(() => {
    const dlg = confirmDialogRef.current;
    if (!dlg) return;
    if (confirmModalOpen && !dlg.open) {
      dlg.showModal();
      confirmBtnRef.current?.focus();
    } else if (!confirmModalOpen && dlg.open) {
      dlg.close();
    }
  }, [confirmModalOpen]);

  const computedTotal = useMemo(() => {
    const p = Number(pieces) || 0;
    const u = Number(units) || 0;
    return (p * u).toLocaleString('pt-BR');
  }, [pieces, units]);

  const getActiveOperator = (): OperatorName => {
    return isAdmin
      ? operator
      : ((profile?.display_name || 'Fernando') as OperatorName);
  };

  const validateSingleField = (
    id: FormFieldId,
    overrides?: Partial<{
      date: string;
      operator: string;
      kind: string;
      measure: string;
      gauge: string;
      pieces: string;
      units: string;
    }>
  ): string => {
    const curDate = overrides?.date ?? date;
    const curOp = overrides?.operator ?? getActiveOperator();
    const curKind = overrides?.kind ?? kind;
    const curMeasure = overrides?.measure ?? measure;
    const curGauge = overrides?.gauge ?? gauge;
    const curPieces = overrides?.pieces ?? pieces;
    const curUnits = overrides?.units ?? units;

    switch (id) {
      case 'date':
        return validDate(curDate) ? '' : 'Selecione uma data válida.';
      case 'operator':
        return OPERATORS.includes(curOp as OperatorName)
          ? ''
          : 'Selecione um operador válido.';
      case 'measure': {
        const trimmed = curMeasure.trim();
        return trimmed && trimmed.length <= 40 && !/[<>]/.test(curMeasure)
          ? ''
          : 'Informe a medida do estribo.';
      }
      case 'gauge':
        return GAUGES.includes(curGauge as (typeof GAUGES)[number])
          ? ''
          : 'Selecione a bitola.';
      case 'kind':
        return KINDS.includes(curKind as (typeof KINDS)[number])
          ? ''
          : 'Selecione o tipo de pacote.';
      case 'pieces':
        return Number.isSafeInteger(Number(curPieces)) && Number(curPieces) > 0
          ? ''
          : 'Informe a quantidade de peças.';
      case 'units': {
        const p = Number(curPieces);
        const u = Number(curUnits);
        return Number.isSafeInteger(u) &&
          u > 0 &&
          Number.isSafeInteger(p * u) &&
          p * u <= 2147483647
          ? ''
          : 'Informe uma quantidade de pacotes válida.';
      }
    }
  };

  const checkField = (
    id: FormFieldId,
    overrides?: Partial<{
      date: string;
      operator: string;
      kind: string;
      measure: string;
      gauge: string;
      pieces: string;
      units: string;
    }>
  ): boolean => {
    const msg = validateSingleField(id, overrides);
    setFieldErrors((prev) => {
      const next = { ...prev };
      if (msg) {
        next[id] = msg;
      } else {
        delete next[id];
      }
      return next;
    });
    return !msg;
  };

  const focusField = (id: FormFieldId) => {
    const map: Record<FormFieldId, React.RefObject<HTMLElement | null>> = {
      date: dateRef,
      operator: operatorRef,
      kind: kindRef,
      measure: measureRef,
      gauge: gaugeRef,
      pieces: piecesRef,
      units: unitsRef,
    };
    map[id]?.current?.focus();
  };

  const activeSequence = (): FormFieldId[] => {
    const fields: FormFieldId[] = [
      'date',
      'operator',
      'kind',
      'gauge',
      'measure',
      'pieces',
      'units',
    ];
    return fields.filter((k) => k !== 'operator' || isAdmin);
  };

  const handleFieldEnter = (
    id: FormFieldId,
    e: React.KeyboardEvent<HTMLElement>
  ) => {
    if (e.key !== 'Enter' || e.nativeEvent.isComposing) return;
    e.preventDefault();
    const seq = activeSequence();
    const idx = seq.indexOf(id);
    if (idx >= 0 && idx < seq.length - 1) {
      focusField(seq[idx + 1]);
    } else if (id === 'units') {
      handleRequestConfirmation();
    }
  };

  const applyKindValue = (nextKind: string) => {
    setKind(nextKind);
    let nextGauge = gauge;
    let nextPieces = pieces;
    const isSpecial = (value: string) => value === 'M.LIVRE' || value === 'CAIXA';
    if (isSpecial(nextKind) && !isSpecial(kind)) {
      beforeSpecialKindRef.current = { gauge, pieces };
    }
    if (nextKind === 'M.LIVRE') {
      nextGauge = '4,2';
      nextPieces = '';
      setGauge('4,2');
      setPieces('');
    } else if (nextKind === 'CAIXA') {
      nextGauge = '4,2';
      nextPieces = '250';
      setGauge('4,2');
      setPieces('250');
    } else if (isSpecial(kind) && beforeSpecialKindRef.current) {
      const before = beforeSpecialKindRef.current;
      if (gauge === '4,2') {
        nextGauge = before.gauge;
        setGauge(before.gauge);
      }
      if (pieces === '' || (kind === 'CAIXA' && pieces === '250')) {
        nextPieces = before.pieces;
        setPieces(before.pieces);
      }
      beforeSpecialKindRef.current = null;
    }

    checkField('kind', { kind: nextKind, gauge: nextGauge, pieces: nextPieces });
    checkField('gauge', { gauge: nextGauge });
    if (nextPieces) {
      checkField('pieces', { pieces: nextPieces });
    } else {
      setFieldErrors((prev) => {
        if (!prev.pieces) return prev;
        const next = { ...prev };
        delete next.pieces;
        return next;
      });
    }
  };

  const resetForm = (
    preserveDate = false,
    operatorToKeep: OperatorName | null = null,
    keepChoices: { gauge: string; kind: string } | null = null
  ) => {
    beforeSpecialKindRef.current = null;
    setEditingId(null);
    setDate((prev) => (preserveDate && validDate(prev) ? prev : today()));
    setGauge((prev) =>
      keepChoices && GAUGES.includes(keepChoices.gauge as (typeof GAUGES)[number])
        ? keepChoices.gauge
        : GAUGES.includes(prev as (typeof GAUGES)[number])
          ? prev
          : '3,8'
    );
    setMeasure('');
    setKind(() =>
      keepChoices && KINDS.includes(keepChoices.kind as (typeof KINDS)[number])
        ? keepChoices.kind
        : 'PACOTE'
    );
    setPieces('');
    setUnits('');
    setFieldErrors({});
    if (isAdmin) {
      setOperator(
        operatorToKeep && OPERATORS.includes(operatorToKeep)
          ? operatorToKeep
          : 'Fernando'
      );
    } else if (profile) {
      setOperator(profile.display_name as OperatorName);
    }
  };

  const handleRequestConfirmation = () => {
    const seq = activeSequence();
    const nextErrors: Partial<Record<FormFieldId, string>> = {};
    let firstInvalid: FormFieldId | null = null;

    for (const id of seq) {
      const msg = validateSingleField(id);
      if (msg) {
        nextErrors[id] = msg;
        if (!firstInvalid) firstInvalid = id;
      }
    }
    setFieldErrors(nextErrors);

    if (firstInvalid) {
      focusField(firstInvalid);
      onNotify(MESSAGES.requiredFields);
      return;
    }
    setConfirmModalOpen(true);
  };

  const executeSave = async () => {
    setConfirmModalOpen(false);
    if (!profile || profile.role === 'administration') return;

    const p = Number(pieces);
    const u = Number(units);
    const op = getActiveOperator();

    if (
      !Number.isSafeInteger(p) ||
      p < 1 ||
      !Number.isSafeInteger(u) ||
      u < 1 ||
      !Number.isSafeInteger(p * u) ||
      p * u > 2147483647
    ) {
      onNotify(
        'Informe quantidades inteiras válidas (total máximo: 2.147.483.647)'
      );
      return;
    }

    const trimmedMeasure = measure.trim();
    if (
      !validDate(date) ||
      !OPERATORS.includes(op) ||
      !GAUGES.includes(gauge as (typeof GAUGES)[number]) ||
      !trimmedMeasure ||
      trimmedMeasure.length > 40 ||
      /[<>]/.test(trimmedMeasure) ||
      !KINDS.includes(kind as (typeof KINDS)[number])
    ) {
      onNotify('Preencha uma medida válida do estribo');
      return;
    }

    const wasEdit = editingId !== null;
    const savedDate = date;
    const savedChoices = { gauge, kind };
    const currentEditingId = editingId;

    setSaving(true);
    try {
      const res = await onSaveProduction({
        editingId: currentEditingId,
        production_date: savedDate,
        operator: op,
        gauge,
        measure: trimmedMeasure,
        package_type: kind,
        pieces_per_unit: p,
        units: u,
      });

      if (res.ok) {
        resetForm(!wasEdit, op, savedChoices);
        onSavedSuccess({
          wasEdit,
          operator: op,
          productionDate: savedDate,
          gauge,
          measure: trimmedMeasure,
          packageType: kind,
          piecesPerUnit: p,
          units: u,
          savedId: res.savedId,
        });
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <aside
        className={`production-sidebar${mobileHidden ? ' mobile-pane-hidden' : ''}`}
      >
        <section className="card sidebar-identity-card" id="identityCard">
          <div className="grid">
            <div
              className={`field${fieldErrors.date ? ' is-invalid' : ''}`}
              data-error={fieldErrors.date || undefined}
            >
              <input
                ref={dateRef}
                aria-invalid={fieldErrors.date ? 'true' : undefined}
                aria-label="Data"
                aria-required="true"
                id="date"
                required
                type="date"
                value={date}
                onBlur={() => {
                  if (date) checkField('date');
                }}
                onChange={(e) => {
                  setDate(e.target.value);
                  checkField('date', { date: e.target.value });
                }}
                onKeyDown={(e) => handleFieldEnter('date', e)}
              />
            </div>

            {isAdmin ? (
              <div
                className={`field${fieldErrors.operator ? ' is-invalid' : ''}`}
                data-error={fieldErrors.operator || undefined}
                id="operatorWrap"
              >
                <select
                  ref={operatorRef}
                  aria-invalid={fieldErrors.operator ? 'true' : undefined}
                  aria-label="Operador"
                  aria-required="true"
                  id="operator"
                  required
                  value={operator}
                  onBlur={() => {
                    if (operator) checkField('operator');
                  }}
                  onChange={(e) => {
                    const nextOp = e.target.value as OperatorName;
                    setOperator(nextOp);
                    checkField('operator', { operator: nextOp });
                  }}
                  onKeyDown={(e) => handleFieldEnter('operator', e)}
                >
                  {OPERATORS.map((op) => (
                    <option key={op} value={op}>
                      {op}
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              <div className="field" id="operatorStatic">
                <div className="total" id="operatorName">
                  {profile?.display_name || ''}
                </div>
              </div>
            )}
          </div>
          {validDate(date) && date.slice(0, 7) < currentMonth && (
            <p className="date-archive-hint">
              Esta data pertence a {fmtMonthYear(date.slice(0, 7))} e aparecerá no Histórico mensal, calculado a partir dos lançamentos existentes.
            </p>
          )}
        </section>

        <section className="card sidebar-form-card" id="formCard">
          <h2 id="formTitle">
            {editingId !== null ? 'Alterar produção' : 'Registrar produção'}
          </h2>
          <div className="grid">
            <div
              className={`field${fieldErrors.kind ? ' is-invalid' : ''}`}
              data-error={fieldErrors.kind || undefined}
            >
              <button
                ref={kindRef}
                aria-invalid={fieldErrors.kind ? 'true' : undefined}
                aria-label={`Pacote selecionado: ${kind}. Toque para mudar.`}
                aria-required="true"
                className="btn secondary package-kind-toggle"
                id="kind"
                type="button"
                onClick={() => {
                  const currentIndex = KINDS.indexOf(
                    kind as (typeof KINDS)[number]
                  );
                  const nextKind = KINDS[(currentIndex + 1) % KINDS.length];
                  applyKindValue(nextKind);
                }}
              >
                {kind}
              </button>
            </div>

            <div
              className={`field${fieldErrors.gauge ? ' is-invalid' : ''}`}
              data-error={fieldErrors.gauge || undefined}
            >
              <button
                ref={gaugeRef}
                aria-invalid={fieldErrors.gauge ? 'true' : undefined}
                aria-label={`Bitola: ${gauge || 'não selecionada'}. Toque para mudar.`}
                aria-required="true"
                className={`btn secondary gauge-toggle ${gaugeTextClass(gauge)}`}
                id="gauge"
                type="button"
                onClick={() => {
                  const currentIndex = GAUGES.indexOf(
                    gauge as (typeof GAUGES)[number]
                  );
                  const nextGauge = GAUGES[(currentIndex + 1) % GAUGES.length];
                  setGauge(nextGauge);
                  checkField('gauge', { gauge: nextGauge });
                }}
              >
                {gauge || 'Bitola'}
              </button>
            </div>

            <div
              className={`field measure-field${fieldErrors.measure ? ' is-invalid' : ''}`}
              data-error={fieldErrors.measure || undefined}
            >
              <input
                ref={measureRef}
                aria-invalid={fieldErrors.measure ? 'true' : undefined}
                aria-label="ESTRIBO"
                aria-required="true"
                autoComplete="off"
                id="measure"
                maxLength={40}
                placeholder="ESTRIBO"
                required
                type="text"
                value={measure}
                onBlur={() => {
                  if (measure) checkField('measure');
                }}
                onChange={(e) => {
                  const val = e.target.value;
                  setMeasure(val);
                  checkField('measure', { measure: val });
                }}
                onKeyDown={(e) => handleFieldEnter('measure', e)}
              />
            </div>

            <div
              className={`field${fieldErrors.pieces ? ' is-invalid' : ''}`}
              data-error={fieldErrors.pieces || undefined}
            >
              <input
                ref={piecesRef}
                aria-invalid={fieldErrors.pieces ? 'true' : undefined}
                aria-label="QUANTIDADE DE ESTRIBOS"
                aria-required="true"
                id="pieces"
                inputMode="numeric"
                min={1}
                placeholder="QTD. ESTRIBOS"
                required
                step={1}
                type="number"
                value={pieces}
                onBlur={() => {
                  if (pieces) checkField('pieces');
                }}
                onChange={(e) => {
                  const val = e.target.value;
                  setPieces(val);
                  checkField('pieces', { pieces: val });
                }}
                onKeyDown={(e) => handleFieldEnter('pieces', e)}
              />
            </div>

            <div
              className={`field${fieldErrors.units ? ' is-invalid' : ''}`}
              data-error={fieldErrors.units || undefined}
            >
              <input
                ref={unitsRef}
                aria-invalid={fieldErrors.units ? 'true' : undefined}
                aria-label="QUANTIDADE DE PACOTES"
                aria-required="true"
                id="units"
                inputMode="numeric"
                min={1}
                placeholder="QTD. PACOTES"
                required
                step={1}
                type="number"
                value={units}
                onBlur={() => {
                  if (units) checkField('units');
                }}
                onChange={(e) => {
                  const val = e.target.value;
                  setUnits(val);
                  checkField('units', { units: val });
                }}
                onKeyDown={(e) => handleFieldEnter('units', e)}
              />
            </div>

            <div className="field total-field">
              <div aria-label="TOTAL" className="total" id="total">
                <span className="total-label">Total</span>
                <span className="total-value">{computedTotal}</span>
              </div>
            </div>
          </div>

          <div className="actions">
            {editingId !== null && (
              <button
                className="btn secondary"
                id="cancelBtn"
                type="button"
                onClick={() => {
                  resetForm(false);
                  onCancelEdit();
                }}
              >
                Cancelar
              </button>
            )}
            <button
              className="btn"
              disabled={saving}
              id="saveBtn"
              type="button"
              onClick={handleRequestConfirmation}
            >
              {saving
                ? 'Salvando…'
                : editingId !== null
                  ? 'Salvar alterações'
                  : 'Salvar produção'}
            </button>
          </div>
        </section>
      </aside>

      <dialog
        ref={confirmDialogRef}
        aria-describedby="productionConfirmHint"
        aria-labelledby="productionConfirmTitle"
        className="confirm-dialog"
        id="productionConfirm"
        onCancel={(e) => {
          e.preventDefault();
          setConfirmModalOpen(false);
        }}
        onClose={() => {
          if (confirmModalOpen) setConfirmModalOpen(false);
        }}
      >
        <h2 id="productionConfirmTitle">Confirme os dados da produção</h2>
        <p id="productionConfirmHint">
          Confira antes de registrar. Nada será salvo até tocar no botão.
        </p>
        <dl className="production-confirm-list" id="productionConfirmDetails">
          <dt>Operador</dt>
          <dd>{getActiveOperator() || '—'}</dd>
          <dt>Data</dt>
          <dd>{date ? fmtDate(date) : '—'}</dd>
          <dt>Tipo de pacote</dt>
          <dd>{kind || '—'}</dd>
          <dt>Estribo</dt>
          <dd>{measure.trim() || '—'}</dd>
          <dt>Bitola</dt>
          <dd>{gauge ? `${gauge} mm` : '—'}</dd>
          <dt>Quantidade de estribos</dt>
          <dd>{Number(pieces || 0).toLocaleString('pt-BR')}</dd>
          <dt>Quantidade de pacotes</dt>
          <dd>{Number(units || 0).toLocaleString('pt-BR')}</dd>
          <dt>Total de peças</dt>
          <dd>{computedTotal}</dd>
        </dl>
        <div className="confirm-actions">
          <button
            className="btn secondary"
            type="button"
            onClick={() => setConfirmModalOpen(false)}
          >
            Cancelar
          </button>
          <button
            ref={confirmBtnRef}
            className="btn"
            id="confirmProductionBtn"
            type="button"
            onClick={() => void executeSave()}
          >
            Confirmar e registrar
          </button>
        </div>
      </dialog>
    </>
  );
}
