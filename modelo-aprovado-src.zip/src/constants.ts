import type { GaugeType, GoalTargets, OperatorName, PackageKind } from './types';

const DEFAULT_SUPABASE_URL = 'https://ohtrlfyncanrqjukaggo.supabase.co';
const DEFAULT_SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_Yaa1244QiYU1SemZlpTrgA_eLdUGuow';

const rawEnvUrl = String(import.meta.env.VITE_SUPABASE_URL || '')
  .replace(/^VITE_SUPABASE_URL=/, '')
  .trim();
const rawEnvKey = String(import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || '')
  .replace(/^VITE_SUPABASE_PUBLISHABLE_KEY=/, '')
  .trim();

export const SUPABASE_URL = /^https?:\/\/.+/.test(rawEnvUrl)
  ? rawEnvUrl
  : DEFAULT_SUPABASE_URL;
export const SUPABASE_PUBLISHABLE_KEY =
  rawEnvKey || DEFAULT_SUPABASE_PUBLISHABLE_KEY;

export const PAGE_SIZE = 6;
export const COILS_PAGE_SIZE = 10;

export const OPERATORS: readonly OperatorName[] = ['Fernando', 'Angelo', 'Denerval'];
export const GAUGES: readonly GaugeType[] = ['3,8', '4,2', '5,0', '6,0'];
export const KINDS: readonly PackageKind[] = ['PACOTE', 'AMARRADO', 'M.LIVRE', 'CAIXA'];

export const DEFAULT_GOALS: GoalTargets = {
  Fernando: 100000,
  Angelo: 100000,
  Denerval: 100000,
};

export const MESSAGES = {
  profileMissing:
    'Esta conta não está associada a um perfil. Peça ao Admin Master para conferir app_profiles.',
  profileInvalid:
    'O perfil está incompleto ou não corresponde a um operador válido. Peça ao Admin Master para conferir app_profiles.',
  requiredFields: 'Confira os campos destacados e complete os dados.',
  reportTitle: 'Relatório de Produção de Estribos',
  monthlyClosingTitle: 'Resumo Mensal de Produção',
  coilsTitle: 'Relatório de Bobinas',
  coilsMonthlyTitle: 'Relatório Mensal de Cadastro de Bobinas',
  reportNoRows: 'Nenhuma produção encontrada no período selecionado.',
  pdfLoad: 'Não foi possível carregar o gerador de PDF. Confira a conexão e tente novamente.',
  pdfProductionOk: 'PDF da produção baixado.',
  pdfCoilsOk: 'PDF de bobinas baixado.',
  pdfCoilsMonthlyOk: 'PDF do relatório mensal de bobinas baixado.',
  xlsxOk: 'Arquivo Excel baixado.',
} as const;

export const rowDate = (value: unknown): string => String(value ?? '').slice(0, 10);

export const localDateFromIso = (value: unknown): string => {
  const str = String(value ?? '').trim();
  if (!str) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str;
  const d = new Date(str);
  if (Number.isNaN(d.getTime())) return str.slice(0, 10);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
};

export const fmtTimeFromIso = (value: unknown): string => {
  const str = String(value ?? '').trim();
  if (!str || /^\d{4}-\d{2}-\d{2}$/.test(str)) return '';
  const d = new Date(str);
  if (Number.isNaN(d.getTime())) return '';
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  return `${hh}:${mm}`;
};

export const fmtMonthYear = (ym: string): string => {
  if (!/^\d{4}-\d{2}$/.test(ym)) return ym;
  const [y, m] = ym.split('-');
  const d = new Date(Number(y), Number(m) - 1, 15);
  const label = d.toLocaleDateString('pt-BR', {
    month: 'long',
    year: 'numeric',
  });
  return label.charAt(0).toUpperCase() + label.slice(1);
};

export const nextMonthFirstDay = (ym: string): string => {
  if (!/^\d{4}-\d{2}$/.test(ym)) return '';
  const [yStr, mStr] = ym.split('-');
  const year = Number(yStr);
  const month = Number(mStr);
  if (!Number.isInteger(year) || !Number.isInteger(month)) return '';
  const nextYear = month === 12 ? year + 1 : year;
  const nextMonth = month === 12 ? 1 : month + 1;
  return `01/${String(nextMonth).padStart(2, '0')}/${nextYear}`;
};

export const fmtKg = (kg: number): string =>
  `${Number(kg || 0).toLocaleString('pt-BR', {
    minimumFractionDigits: 3,
    maximumFractionDigits: 3,
  })} kg`;

export const today = (): string => {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
};

export const fmtDate = (s: string): string => {
  if (!s) return '';
  const [y, m, d] = s.split('-');
  return `${d}/${m}/${y}`;
};

export const validDate = (s: string): boolean => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T12:00:00`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
};

export const gaugeTextClass = (gauge: string): string => {
  const map: Record<string, string> = {
    '3,8': 'gauge-text-38',
    '4,2': 'gauge-text-42',
    '5,0': 'gauge-text-50',
    '6,0': 'gauge-text-60',
  };
  return map[String(gauge)] || '';
};

export const packageValueForLetter = (letter: string): PackageKind | '' => {
  const normalized = String(letter).trim().toUpperCase();
  if (!normalized) return '';
  const map: Record<string, PackageKind> = {
    P: 'PACOTE',
    A: 'AMARRADO',
    M: 'M.LIVRE',
    C: 'CAIXA',
  };
  return map[normalized.charAt(0)] || '';
};

export const gaugeValueForDigit = (digit: string): GaugeType | '' => {
  const map: Record<string, GaugeType> = {
    '3': '3,8',
    '4': '4,2',
    '5': '5,0',
    '6': '6,0',
  };
  return map[digit] || '';
};
