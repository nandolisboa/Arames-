import { jsPDF } from 'jspdf';
import * as XLSX from 'xlsx';
import { ARAMES_LOGO_DATA_URL } from '../assets/logo';
import {
  GAUGES,
  MESSAGES,
  OPERATORS,
  fmtDate,
  fmtKg,
  fmtMonthYear,
  fmtTimeFromIso,
  localDateFromIso,
  rowDate,
  today,
} from '../constants';
import type { CoilRow, OperatorName, ProductionRow } from '../types';
import { formatCoilWeightsForReport } from './coilWeights';

export type PrintOperatorFilter = 'all' | OperatorName;
/** Export the currently filtered production rows as a workbook grouped by operator. */
export function exportProductionExcel(
  rows: ProductionRow[],
  dateFilter: 'month' | 'today',
  onNotify: (msg: string) => void
): void {
  const period = dateFilter === 'today' ? 'Hoje' : 'Este mês';
  const groups = OPERATORS.map((operator) => ({
    operator,
    rows: rows.filter((row) => row.operator === operator),
  }));
  const headers = ['Data', 'Bitola mm', 'Medida do estribo', 'Pacote', 'Peças por pacote', 'Pacotes', 'Total peças'];
  const blockWidth = 8;
  const maxRows = Math.max(0, ...groups.map((group) => group.rows.length));
  const subtotalRow = 4 + maxRows;
  const grandTotalRow = subtotalRow + 1;
  const sheet: (string | number)[][] = [];
  sheet[0] = ['RELATÓRIO DE PRODUÇÃO POR OPERADOR'];
  sheet[1] = ['Período', period];
  groups.forEach((group, index) => {
    const start = index * blockWidth;
    sheet[2] ??= [];
    sheet[2][start] = 'OPERADOR';
    sheet[2][start + 1] = group.operator;
    sheet[3] ??= [];
    headers.forEach((header, col) => { sheet[3][start + col] = header; });
    group.rows.forEach((row, indexInGroup) => {
      const values: (string | number)[] = [
        fmtDate(rowDate(row.production_date)), row.gauge, row.measure, row.package_type,
        Number(row.pieces_per_unit), Number(row.units), Number(row.total_pieces),
      ];
      sheet[4 + indexInGroup] ??= [];
      values.forEach((value, col) => { sheet[4 + indexInGroup][start + col] = value; });
    });
    sheet[subtotalRow] ??= [];
    sheet[subtotalRow][start] = `SUBTOTAL ${group.operator}`;
    sheet[subtotalRow][start + 6] = group.rows.reduce((sum, row) => sum + Number(row.total_pieces || 0), 0);
  });
  sheet[grandTotalRow] ??= [];
  sheet[grandTotalRow][0] = 'TOTAL GERAL';
  sheet[grandTotalRow][6] = groups.reduce((sum, group) => sum + group.rows.reduce((subtotal, row) => subtotal + Number(row.total_pieces || 0), 0), 0);
  const worksheet = XLSX.utils.aoa_to_sheet(sheet);
  worksheet['!cols'] = groups.flatMap(() => [
    { wch: 13 }, { wch: 12 }, { wch: 22 }, { wch: 15 },
    { wch: 17 }, { wch: 12 }, { wch: 14 }, { wch: 3 },
  ]);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Produção');
  XLSX.writeFile(workbook, 'relatorio_producao_por_operador.xlsx');
  onNotify(MESSAGES.xlsxOk);
}


export interface PdfPreviewData {
  type: 'production' | 'coils' | 'coils-monthly';
  title: string;
  issuedAt: string;
  filterNote?: string;
  filename: string;
  doc: jsPDF;
  downloadSuccessMessage: string;
  operatorFilter?: PrintOperatorFilter;
  monthFilter?: string;
  availableMonths?: string[];
  productionRows?: ProductionRow[];
  coilRows?: CoilRow[];
}

export interface ProductionReportColumn {
  label: string;
  pdfWidth: number;
  htmlWidthPct: number;
  align: 'left' | 'right';
}

export const PRODUCTION_REPORT_COLUMNS: readonly ProductionReportColumn[] = [
  { label: 'Data', pdfWidth: 26, htmlWidthPct: 13, align: 'left' },
  { label: 'Bitola', pdfWidth: 18, htmlWidthPct: 9, align: 'left' },
  { label: 'Medida do estribo', pdfWidth: 43, htmlWidthPct: 21.5, align: 'left' },
  { label: 'Pacote', pdfWidth: 23, htmlWidthPct: 11.5, align: 'left' },
  { label: 'Qtd de peças', pdfWidth: 29, htmlWidthPct: 14.5, align: 'right' },
  { label: 'Qtd de pacotes', pdfWidth: 39, htmlWidthPct: 19.5, align: 'right' },
  { label: 'Total', pdfWidth: 22, htmlWidthPct: 11, align: 'right' },
];

export interface CoilsReportColumn {
  label: string;
  pdfWidth: number;
  align: 'left' | 'right';
}

export const COILS_REPORT_COLUMNS: readonly CoilsReportColumn[] = [
  { label: 'Data', pdfWidth: 27, align: 'left' },
  { label: 'Bobina (mm)', pdfWidth: 24, align: 'left' },
  { label: 'Fabricante', pdfWidth: 64, align: 'left' },
  { label: 'Nº da NF', pdfWidth: 50, align: 'left' },
  { label: 'Série', pdfWidth: 16, align: 'left' },
  { label: 'Peso (kg)', pdfWidth: 46, align: 'right' },
  { label: 'Origem do peso', pdfWidth: 42, align: 'left' },
];

export const COILS_MONTHLY_DAY_COLUMNS: readonly CoilsReportColumn[] = [
  { label: 'Hora', pdfWidth: 22, align: 'left' },
  { label: 'Bobina (mm)', pdfWidth: 24, align: 'left' },
  { label: 'Fabricante', pdfWidth: 66, align: 'left' },
  { label: 'Nº da NF', pdfWidth: 53, align: 'left' },
  { label: 'Série', pdfWidth: 16, align: 'left' },
  { label: 'Peso (kg)', pdfWidth: 46, align: 'right' },
  { label: 'Origem do peso', pdfWidth: 42, align: 'left' },
];

export interface ProductionReportGroup {
  operator: OperatorName;
  rows: ProductionRow[];
  subtotal: number;
}

export interface CoilsGaugeSummary {
  gauge: string;
  count: number;
  totalWeightKg: number;
}

export interface CoilsDayGroup {
  date: string;
  count: number;
  totalWeightKg: number;
  rows: CoilRow[];
}

export function formatWeightSourceLabel(source: string): string {
  if (source === 'ETIQUETA') return 'Etiqueta';
  if (source === 'AMBOS') return 'Ambos';
  return 'Balança';
}

export interface ProductionReportOptions {
  titleBase?: string;
  filenamePrefix?: string;
}

export function getProductionReportSummary(
  rows: ProductionRow[],
  operatorFilter: PrintOperatorFilter = 'all',
  options?: ProductionReportOptions
): {
  targetRows: ProductionRow[];
  groups: ProductionReportGroup[];
  grandTotal: number;
  totalLabel: string;
  title: string;
  filename: string;
} {
  const targetRows =
    operatorFilter === 'all'
      ? rows
      : rows.filter((r) => r.operator === operatorFilter);

  const groups: ProductionReportGroup[] = [];
  for (const op of OPERATORS) {
    const list = targetRows.filter((r) => r.operator === op);
    if (list.length) {
      groups.push({
        operator: op,
        rows: list,
        subtotal: list.reduce((acc, r) => acc + Number(r.total_pieces), 0),
      });
    }
  }

  const grandTotal = targetRows.reduce(
    (sum, row) => sum + Number(row.total_pieces),
    0
  );
  const totalLabel =
    operatorFilter === 'all'
      ? 'TOTAL GERAL'
      : `TOTAL ${operatorFilter.toLocaleUpperCase('pt-BR')}`;
  const baseTitle = options?.titleBase || MESSAGES.reportTitle;
  const title =
    operatorFilter === 'all'
      ? baseTitle
      : `${baseTitle} — ${operatorFilter}`;
  const suffix =
    operatorFilter === 'all'
      ? ''
      : `_${operatorFilter.toLocaleLowerCase('pt-BR')}`;
  const filePrefix = options?.filenamePrefix || 'relatorio_producao_estribos';

  return {
    targetRows,
    groups,
    grandTotal,
    totalLabel,
    title,
    filename: `${filePrefix}${suffix}.pdf`,
  };
}

export function getCoilsMonthlyReportSummary(
  coilRows: CoilRow[],
  month: string
): {
  monthRows: CoilRow[];
  totalCount: number;
  totalWeightKg: number;
  byGauge: CoilsGaugeSummary[];
  byDay: CoilsDayGroup[];
} {
  const monthRows = coilRows.filter(
    (c) => localDateFromIso(c.created_at).slice(0, 7) === month
  );

  const totalCount = monthRows.length;
  const totalWeightKg = monthRows.reduce(
    (sum, c) => sum + Number(c.weight_kg || 0),
    0
  );

  const gaugeMap = new Map<string, { count: number; totalWeightKg: number }>();
  for (const c of monthRows) {
    const g = String(c.gauge || '');
    const entry = gaugeMap.get(g) || { count: 0, totalWeightKg: 0 };
    entry.count += 1;
    entry.totalWeightKg += Number(c.weight_kg || 0);
    gaugeMap.set(g, entry);
  }

  const orderedGauges = [
    ...GAUGES.filter((g) => gaugeMap.has(g)),
    ...Array.from(gaugeMap.keys()).filter(
      (g) => !GAUGES.includes(g as (typeof GAUGES)[number])
    ),
  ];

  const byGauge: CoilsGaugeSummary[] = orderedGauges.map((g) => {
    const entry = gaugeMap.get(g)!;
    return { gauge: g, count: entry.count, totalWeightKg: entry.totalWeightKg };
  });

  const dayMap = new Map<string, CoilRow[]>();
  for (const c of monthRows) {
    const day = localDateFromIso(c.created_at) || 'Sem data';
    const list = dayMap.get(day);
    if (list) list.push(c);
    else dayMap.set(day, [c]);
  }

  const byDay: CoilsDayGroup[] = Array.from(dayMap.entries())
    .sort(([a], [b]) => b.localeCompare(a))
    .map(([date, rows]) => ({
      date,
      count: rows.length,
      totalWeightKg: rows.reduce((sum, c) => sum + Number(c.weight_kg || 0), 0),
      rows,
    }));

  return {
    monthRows,
    totalCount,
    totalWeightKg,
    byGauge,
    byDay,
  };
}

function addCompanyLogo(doc: jsPDF): void {
  const pageCount = doc.getNumberOfPages();
  for (let page = 1; page <= pageCount; page++) {
    doc.setPage(page);
    doc.addImage(
      ARAMES_LOGO_DATA_URL,
      'PNG',
      doc.internal.pageSize.getWidth() - 55,
      4,
      50,
      7.14,
      'arames-brasil-logo',
      'FAST'
    );
  }
}

function buildProductionPDFDoc(
  rows: ProductionRow[],
  operatorFilter: PrintOperatorFilter = 'all',
  filterNote?: string,
  options?: ProductionReportOptions
): jsPDF {
  const { targetRows, groups, grandTotal, totalLabel, title } =
    getProductionReportSummary(rows, operatorFilter, options);

  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const margin = 5;
  const pageW = 210;
  const pageH = 297;
  let y = 0;

  const metaLine = filterNote
    ? `Emitido em ${fmtDate(today())} • ${filterNote}`
    : `Emitido em ${fmtDate(today())}`;

  const pageTop = () => {
    doc.setTextColor(0, 0, 0);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.text(title, margin, 10);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.text(metaLine, margin, 15);
    doc.setDrawColor(100, 100, 100);
    doc.setLineWidth(0.15);
    doc.line(margin, 17, pageW - margin, 17);
    y = 19;
  };

  const tableHead = () => {
    const h = 10;
    let x = margin;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.8);
    doc.setTextColor(0, 0, 0);
    doc.setDrawColor(120, 120, 120);
    doc.setLineWidth(0.12);
    for (const col of PRODUCTION_REPORT_COLUMNS) {
      doc.rect(x, y, col.pdfWidth, h);
      const label = doc.splitTextToSize(col.label, col.pdfWidth - 2);
      doc.text(label, x + 1, y + 3.5, { lineHeightFactor: 1.1 });
      x += col.pdfWidth;
    }
    y += h;
  };

  const operatorHeader = (operator: string, continuation = false) => {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.text(`${operator}${continuation ? ' (continuação)' : ''}`, margin, y + 3);
    y += 5;
    tableHead();
  };

  const nextPage = (operator?: string) => {
    doc.addPage('a4', 'portrait');
    pageTop();
    if (operator) operatorHeader(operator, true);
  };

  pageTop();
  if (!targetRows.length) {
    doc.setFontSize(9);
    doc.text(MESSAGES.reportNoRows, margin, y + 6);
  } else {
    for (const [groupIndex, group] of groups.entries()) {
      if (groupIndex > 0) nextPage();
      operatorHeader(group.operator);

      for (const [index, row] of group.rows.entries()) {
        const values = [
          fmtDate(rowDate(row.production_date)),
          `${String(row.gauge)} mm`,
          String(row.measure || ''),
          String(row.package_type),
          Number(row.pieces_per_unit).toLocaleString('pt-BR'),
          Number(row.units).toLocaleString('pt-BR'),
          Number(row.total_pieces).toLocaleString('pt-BR'),
        ];
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(7.4);
        const cells = values.map((v, i) =>
          doc.splitTextToSize(v, PRODUCTION_REPORT_COLUMNS[i].pdfWidth - 2)
        );
        const lineCount = Math.max(...cells.map((cell: string[]) => cell.length));
        const rowHeight = Math.max(7.55, lineCount * 3.1 + 2);
        const lastOfGroup = index === group.rows.length - 1;
        const lastGroup = groupIndex === groups.length - 1;
        const footer = lastOfGroup
          ? (groups.length > 1 ? 8 : 0) + (lastGroup ? 8 : 0)
          : 0;
        if (y + rowHeight + footer > pageH - margin) nextPage(group.operator);
        let x = margin;
        doc.setDrawColor(160, 160, 160);
        doc.setLineWidth(0.1);
        for (let i = 0; i < PRODUCTION_REPORT_COLUMNS.length; i++) {
          const col = PRODUCTION_REPORT_COLUMNS[i];
          doc.rect(x, y, col.pdfWidth, rowHeight);
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(7.4);
          doc.setTextColor(0, 0, 0);
          if (col.align === 'right') {
            doc.text(cells[i], x + col.pdfWidth - 1, y + 4.8, {
              align: 'right',
              lineHeightFactor: 1.1,
            });
          } else {
            doc.text(cells[i], x + 1, y + 4.8, { lineHeightFactor: 1.1 });
          }
          x += col.pdfWidth;
        }
        y += rowHeight;
      }

      if (groups.length > 1) {
        if (y + 8 > pageH - margin) nextPage();
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7.4);
        doc.text(
          `Subtotal ${group.operator}: ${group.subtotal.toLocaleString('pt-BR')} peças`,
          pageW - margin,
          y + 4.5,
          { align: 'right' }
        );
        y += 8;
      }
    }

    if (y + 8 > pageH - margin) nextPage();
    doc.setDrawColor(0, 0, 0);
    doc.line(margin, y, pageW - margin, y);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.text(
      `${totalLabel}: ${grandTotal.toLocaleString('pt-BR')} peças`,
      pageW - margin,
      y + 5,
      { align: 'right' }
    );
  }
  addCompanyLogo(doc);
  return doc;
}

export function createProductionPdfPreview(
  rows: ProductionRow[],
  onNotify: (msg: string) => void,
  operatorFilter: PrintOperatorFilter = 'all',
  filterNote?: string,
  options?: ProductionReportOptions
): PdfPreviewData | null {
  try {
    const { targetRows, title, filename } = getProductionReportSummary(
      rows,
      operatorFilter,
      options
    );
    const doc = buildProductionPDFDoc(
      targetRows,
      operatorFilter,
      filterNote,
      options
    );
    return {
      type: 'production',
      title,
      issuedAt: fmtDate(today()),
      filterNote,
      filename,
      doc,
      downloadSuccessMessage: MESSAGES.pdfProductionOk,
      operatorFilter,
      productionRows: targetRows,
    };
  } catch (e) {
    console.error(e);
    onNotify('Não foi possível gerar o PDF da produção. Tente novamente.');
    return null;
  }
}

function buildCoilsPDFDoc(coilRows: CoilRow[], filterNote?: string): jsPDF {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });
  const margin = 14;
  const pageH = 210;
  let y = 0;

  const metaLine = filterNote
    ? `Emitido em ${fmtDate(today())} • ${filterNote}`
    : `Emitido em ${fmtDate(today())}`;

  const pageTop = () => {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.text(MESSAGES.coilsTitle, margin, 15);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text(metaLine, margin, 21);
    y = 28;
  };

  const header = () => {
    let x = margin;
    const h = 9;
    doc.setDrawColor(195, 202, 208);
    doc.setTextColor(0, 0, 0);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    for (const c of COILS_REPORT_COLUMNS) {
      doc.text(c.label, x + 2, y + 6);
      x += c.pdfWidth;
    }
    doc.line(margin, y + h, 283, y + h);
    y += h;
  };

  const nextPage = () => {
    doc.addPage('a4', 'landscape');
    pageTop();
    header();
  };

  pageTop();
  header();

  const rows = coilRows.length
    ? coilRows.map((c) => [
        fmtDate(localDateFromIso(c.created_at)) || '—',
        `${String(c.gauge)} mm`,
        String(c.manufacturer || ''),
        String(c.invoice_number || ''),
        String(c.invoice_series || ''),
        formatCoilWeightsForReport(c),
        formatWeightSourceLabel(c.weight_source),
      ])
    : [['', '', '', '', '', '', 'Nenhuma bobina cadastrada']];

  for (const row of rows) {
    const cells = row.map((v, i) =>
      doc.splitTextToSize(String(v), COILS_REPORT_COLUMNS[i].pdfWidth - 4)
    );
    let lines = 1;
    for (const c of cells) lines = Math.max(lines, c.length);
    const h = Math.max(9, lines * 4.5 + 3);
    if (y + h > pageH - 13) nextPage();
    let x = margin;
    for (let i = 0; i < COILS_REPORT_COLUMNS.length; i++) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(0, 0, 0);
      doc.text(cells[i], x + 2, y + 5.8);
      x += COILS_REPORT_COLUMNS[i].pdfWidth;
    }
    doc.setDrawColor(230, 233, 236);
    doc.line(14, y + h, 283, y + h);
    y += h;
  }

  addCompanyLogo(doc);
  return doc;
}

function buildCoilsMonthlyPDFDoc(coilRows: CoilRow[], month: string): jsPDF {
  const summary = getCoilsMonthlyReportSummary(coilRows, month);
  const monthLabel = fmtMonthYear(month);
  const title = `${MESSAGES.coilsMonthlyTitle} — ${monthLabel}`;

  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });
  const margin = 14;
  const pageW = 297;
  const pageH = 210;
  let y = 0;

  const pageTop = () => {
    doc.setTextColor(0, 0, 0);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(15);
    doc.text(title, margin, 14);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text(`Emitido em ${fmtDate(today())}`, margin, 20);
    doc.setDrawColor(180, 185, 192);
    doc.setLineWidth(0.2);
    doc.line(margin, 23, pageW - margin, 23);
    y = 28;
  };

  const dayTableHead = () => {
    let x = margin;
    const h = 8;
    doc.setDrawColor(195, 202, 208);
    doc.setTextColor(0, 0, 0);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    for (const c of COILS_MONTHLY_DAY_COLUMNS) {
      doc.text(c.label, x + 2, y + 5.5);
      x += c.pdfWidth;
    }
    doc.line(margin, y + h, pageW - margin, y + h);
    y += h;
  };

  const drawDayBanner = (day: CoilsDayGroup, continuation = false) => {
    const label = day.date === 'Sem data' ? 'Sem data' : fmtDate(day.date);
    const suffix = continuation ? ' (continuação)' : '';
    const countLabel = `${day.count} ${day.count === 1 ? 'bobina' : 'bobinas'}`;
    doc.setFillColor(244, 246, 248);
    doc.rect(margin, y, pageW - margin * 2, 7, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(17, 24, 39);
    doc.text(`${label}${suffix}`, margin + 2, y + 4.8);
    doc.text(
      `${countLabel} • ${fmtKg(day.totalWeightKg)}`,
      pageW - margin - 2,
      y + 4.8,
      { align: 'right' }
    );
    y += 8;
    dayTableHead();
  };

  const nextPage = (day?: CoilsDayGroup) => {
    doc.addPage('a4', 'landscape');
    pageTop();
    if (day) drawDayBanner(day, true);
  };

  pageTop();

  if (!summary.totalCount) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.text('Nenhuma bobina cadastrada neste mês.', margin, y + 6);
    addCompanyLogo(doc);
    return doc;
  }

  // Monthly totals summary line
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(215, 220, 227);
  doc.rect(margin, y, pageW - margin * 2, 10, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text(
    `Total no mês: ${summary.totalCount} ${summary.totalCount === 1 ? 'bobina' : 'bobinas'}`,
    margin + 4,
    y + 6.5
  );
  doc.text(
    `Peso total cadastrado: ${fmtKg(summary.totalWeightKg)}`,
    pageW - margin - 4,
    y + 6.5,
    { align: 'right' }
  );
  y += 14;

  // Gauge breakdown compact summary
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text('Resumo por bitola', margin, y + 3);
  y += 5;

  const gaugeCols = [45, 45, 65];
  doc.setFontSize(8.5);
  doc.setDrawColor(195, 202, 208);
  doc.text('Bitola', margin + 2, y + 5);
  doc.text('Qtd. bobinas', margin + gaugeCols[0] + 2, y + 5);
  doc.text('Peso total', margin + gaugeCols[0] + gaugeCols[1] + 2, y + 5);
  doc.line(margin, y + 7, margin + 155, y + 7);
  y += 7;

  for (const g of summary.byGauge) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.text(`${g.gauge} mm`, margin + 2, y + 5);
    doc.text(String(g.count), margin + gaugeCols[0] + 2, y + 5);
    doc.text(fmtKg(g.totalWeightKg), margin + gaugeCols[0] + gaugeCols[1] + 2, y + 5);
    doc.setDrawColor(230, 233, 236);
    doc.line(margin, y + 7, margin + 155, y + 7);
    y += 7;
  }
  y += 7;

  // Daily breakdown
  for (const day of summary.byDay) {
    if (y + 26 > pageH - 12) nextPage();
    drawDayBanner(day);

    for (const c of day.rows) {
      const row = [
        fmtTimeFromIso(c.created_at) || '—',
        `${String(c.gauge)} mm`,
        String(c.manufacturer || ''),
        String(c.invoice_number || ''),
        String(c.invoice_series || ''),
        formatCoilWeightsForReport(c),
        formatWeightSourceLabel(c.weight_source),
      ];
      const cells = row.map((v, i) =>
        doc.splitTextToSize(
          String(v),
          COILS_MONTHLY_DAY_COLUMNS[i].pdfWidth - 4
        )
      );
      const lines = Math.max(1, ...cells.map((cell: string[]) => cell.length));
      const h = Math.max(8, lines * 4.2 + 2.5);
      if (y + h > pageH - 12) nextPage(day);
      let x = margin;
      for (let i = 0; i < COILS_MONTHLY_DAY_COLUMNS.length; i++) {
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8.5);
        doc.setTextColor(0, 0, 0);
        doc.text(cells[i], x + 2, y + 5.2);
        x += COILS_MONTHLY_DAY_COLUMNS[i].pdfWidth;
      }
      doc.setDrawColor(230, 233, 236);
      doc.line(margin, y + h, pageW - margin, y + h);
      y += h;
    }
    y += 5;
  }

  addCompanyLogo(doc);
  return doc;
}

export function downloadCoilsPDF(
  coilRows: CoilRow[],
  onNotify: (msg: string) => void,
  filterNote?: string
): void {
  try {
    const doc = buildCoilsPDFDoc(coilRows, filterNote);
    doc.save('relatorio_bobinas.pdf');
    onNotify(MESSAGES.pdfCoilsOk);
  } catch (e) {
    console.error(e);
    onNotify('Não foi possível gerar o PDF das bobinas. Tente novamente.');
  }
}

export function createCoilsPdfPreview(
  coilRows: CoilRow[],
  onNotify: (msg: string) => void,
  filterNote?: string
): PdfPreviewData | null {
  try {
    const doc = buildCoilsPDFDoc(coilRows, filterNote);
    return {
      type: 'coils',
      title: MESSAGES.coilsTitle,
      issuedAt: fmtDate(today()),
      filterNote,
      filename: 'relatorio_bobinas.pdf',
      doc,
      downloadSuccessMessage: MESSAGES.pdfCoilsOk,
      coilRows,
    };
  } catch (e) {
    console.error(e);
    onNotify('Não foi possível gerar o PDF das bobinas. Tente novamente.');
    return null;
  }
}

export function createCoilsMonthlyPdfPreview(
  coilRows: CoilRow[],
  month: string,
  availableMonths: string[],
  onNotify: (msg: string) => void
): PdfPreviewData | null {
  try {
    const doc = buildCoilsMonthlyPDFDoc(coilRows, month);
    const monthLabel = fmtMonthYear(month);
    return {
      type: 'coils-monthly',
      title: `${MESSAGES.coilsMonthlyTitle} — ${monthLabel}`,
      issuedAt: fmtDate(today()),
      filename: `relatorio_mensal_bobinas_${month}.pdf`,
      doc,
      downloadSuccessMessage: MESSAGES.pdfCoilsMonthlyOk,
      monthFilter: month,
      availableMonths,
      coilRows,
    };
  } catch (e) {
    console.error(e);
    onNotify('Não foi possível gerar o relatório mensal das bobinas. Tente novamente.');
    return null;
  }
}
